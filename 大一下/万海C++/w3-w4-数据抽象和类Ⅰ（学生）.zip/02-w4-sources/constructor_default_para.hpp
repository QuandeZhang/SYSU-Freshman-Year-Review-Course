/* constructor_default_para.hpp */
#pragma once
#include <iostream> 

namespace sysu_cplus {
    class Line { 
        public: 
            Line(double len = 0); //���캯�� 
            void setLength( double len );     
            double getLength( void );
        private: 
            double length; 
    }; 
}

// ��Ա�������壬�������캯�� 
sysu_cplus::Line::Line(double len) { 
    length = len;
    std::cout << "Object is being created, length = " << len << std::endl; 
} 
void sysu_cplus::Line::setLength( double len ) { 
    length = len; 
}
double sysu_cplus::Line::getLength( void ) { 
    return length; 
} 
