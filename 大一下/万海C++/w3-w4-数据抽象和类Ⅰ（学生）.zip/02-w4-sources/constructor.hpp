/* constractor.hpp */
#pragma once
#include<iostream> 

namespace sysu_cplus { 
    class Line { 
        public: 
            void setLength( double len ); 
            double getLength( void ); 
            Line(); // ���ǹ��캯�� 
        private: 
            double length; 
    }; 
}
// ��Ա�������壬�������캯�� 
sysu_cplus::Line::Line(void) { 
    std::cout << "Object is being created" << std::endl; 
} 
void sysu_cplus::Line::setLength( double len ) { 
    length = len; 
}
double sysu_cplus::Line::getLength( void ) { 
    return length; 
} 
