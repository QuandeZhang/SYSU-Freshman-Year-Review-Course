#include<iostream>
#include<typeinfo>

#define NEW(x) *(new x)
#define DEL(x) delete &x

using namespace std;

class AbstractAnimal {
public:
    virtual void eat() = 0;
    virtual ~AbstractAnimal() {cout << "~Animal" << endl;}
}; 

class Duck:virtual public AbstractAnimal {
public:
    void eat() final {cout << "guagua" << endl;}; 
    ~Duck() {cout << "~Duck" << endl;};
}; 

class Actor:virtual public AbstractAnimal {
public:
    virtual void play() = 0; 
    ~Actor() {cout << "~Actor" << endl;}
};

class Donald final:public Duck, public Actor {
    //EX1: ���� eat �� play �Ƿ񶼱���ʵ�֣� 
    void play() {cout << "Comic" << endl;} 
    ~Donald() {cout << "~Donald" << endl;}
}; 

void dynamic_casting_err() {
    AbstractAnimal* a = new Duck;
    Actor* c = dynamic_cast<Actor*>(a);
    if (!c) {
        cout << "nullptr" << endl;
    }
}

int main() {
    //���� 
    AbstractAnimal& a = NEW(Donald);
    cout << typeid(AbstractAnimal).name() <<","
         << typeid(Donald).name() << endl; 
    cout << typeid(a).name() << endl;
    //����
    Duck& d = dynamic_cast<Duck&>(a);
    d.eat();
    //���� 
    Actor& c = dynamic_cast<Actor&>(d);
    c.eat();
    c.play();
    // EX2: Animal ������������
    // EX3: a ��Ϊ c , �о������������������Ĳ�ͬ 
    DEL(a);
    
    dynamic_casting_err();
} 



