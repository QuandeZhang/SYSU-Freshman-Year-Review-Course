/***********************
���л����� dev c++ + EGE
EGE����:   https://xege.org/
EGE����:   ege20.08_all 
����˵����
    ������չʾͼ�ζ�����ܵ�ʹ�� 
************************/ 
#include<iostream>
#include<math.h>
#include"graphical_dynamic_framework.hpp" 
#include"graphical_dynamic_framework_ext.hpp"

class SimuFrame: public SimulationSystemSimpleAbstractFramwork {
    //������滷������ 
    double alpha;
    int r;
    int delta;
    int sign; 
    int x0,y0;
    
    Point* p; 
    Circle* circle;
    FiveStar* star;
    
    void init() {
        p = new Point(0,0);
        circle = new Circle(0,0,10);
        star = new FiveStar(0,0,50);
        
        alpha = 0;
        r = 100;
        delta = 1;
        sign = 1;
        x0=300,y0=200;        
    }
    
    void tick() {
        //ģ�ͼ��� 
        alpha += 0.02;  
        if (alpha > PI * 2) {
            sign = -sign;
            alpha -= PI * 2; 
        }
        int x = x0 - r*cos(alpha);
        int y = y0 + r*sin(alpha);
        
        p->moveTo(x,y);
        circle->moveTo(x0,y0);
        circle->expand(sign*delta); 
        star->moveTo(x,y0);   
        star->rotate(0.03);        
    }
} my_frame;

int main() {
    my_frame.run();
    return 0;
}


