#pragma once
/***********************
���л����� dev c++ + EGE
EGE����:   https://xege.org/
EGE����:   ege20.08_all 
����˵����
  ��չͼ�ζ����ʾ����ע�� shape ���ܼ̳� shape ���� 
************************/ 

#include<string>
#include"graphical_dynamic_framework.hpp" 
using namespace std;

class FiveStar final:public AbstractShape2D {
    double r;
    double a = 0;
    public:
        FiveStar(double x, double y, double r):AbstractShape2D("star") {
            moveTo(x,y); 
            this->r = r;
        };
//modified members
        float getArea() {return 0;}
        float getPerimeter() {return 0;}
        //rotate ������ͼ�ζ��߱��Ĺ��ܣ���θģ� 
        void rotate(double delta_a) {
            a += delta_a;
        }
        void draw();
};


//ext.cpp
#include<graphics.h>
#include<iostream>
using namespace std;

//---Point--------------------
void FiveStar::draw() {
    if (isVisible()) {
        double x = origin.x;
        double y = origin.y;
        int pt[10];
        for (int n = 0; n < 5; ++n)
        {
            pt[n*2] = (int)( -cos( PI * 4 / 5 * n + a ) * r + x );
            pt[n*2+1] = (int)( sin( PI * 4 / 5 * n + a) * r + y );
        }
        fillpoly(5, pt);
    }
}

