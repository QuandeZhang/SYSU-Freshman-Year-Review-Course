#include<iostream>
using namespace std;

class Animal {
    public:
        void eat() {
            cout << "I like food!" << endl;
        };
};

void whatDoYouPrefer(Animal &animal) {
	animal.eat();
} 

class Dog:public Animal {
    public:
        void eat() {
            cout << "I like bones!" << endl;
        };
        ~Dog() {cout << "auto destructed!\n";};
};

class Cat:public Animal {
    public:
        void eat() {
            cout << "I like fishes!" << endl;
        };
};


int main() {
	Animal &&cat=Cat(), &&dog=Dog(); //������﷨�ǣ� 
//	Cat temp;
//	Animal &cat=temp; 
	whatDoYouPrefer(cat);
	whatDoYouPrefer(dog);
	
	//ex: �����Bear�� 
//	Bear bear;
//	whatDoYouPrefer(bear); 
}
