#include <iostream>
#include <string>

using namespace std;

/* ��������û�ָ�� */
template <typename T, int N>
void printValues(T (&arr)[N]) {
	cout << "(T&)[" << N << "]\n";
    for (int i = 0; i != N; ++i)
	    cout<< arr[i] << ","; 
	cout << endl;
}

// EX1: ��ĶԸó��� 
template <typename T, int N>
void printValues(T (*arr)[N]) {
	cout << "(T*)[" << N << "]\n"; 
    for (int i = 0; i != N; ++i)
	    cout<< arr[i] << ","; 
	cout << endl;
}

/* ��ʹ�÷�ģ���β�ʵ�� */
template <typename T>
void printValues(T* arr, int N) {
	cout << "T*" << "\n";
    for (int i = 0; i != N; ++i)
	    cout<< arr[i] << ","; 
	cout << endl;
}

int main()
{
    int intArr[6] = {1, 2, 3, 4, 5, 6};
    double dblArr[4] = {1.2, 2.3, 3.4, 4.5};

    // ���ɺ���ʵ��printValues(int (&) [6])
    printValues(intArr);	
    // ���ɺ���ʵ��printValues(double (&) [4])
    printValues(dblArr);
	//���� ?
	printValues(&dblArr);
	//  
	printValues(intArr, 6);	
    
    return 0;
}
