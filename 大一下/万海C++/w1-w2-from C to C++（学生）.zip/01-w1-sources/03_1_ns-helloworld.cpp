/* ns-helloworld.cpp */
#include<iostream>
using namespace std;

int main() {
    char *cout = "hello world c++!"; 
    std::cout << cout << endl;
    return 0;
}
 
