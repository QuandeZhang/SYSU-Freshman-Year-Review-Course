/* helloworld.cpp */
#include<iostream>
using namespace std;

int main() {
    cout << "hello world c++!" << endl;
    return 0;
}
 
