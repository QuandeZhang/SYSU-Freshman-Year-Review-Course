/* string-create-objects*/
#include<iostream>
#include<string>
using namespace std;

int main() {
    string s1;
    string s2 = "c++";
    string s3 = s2;
    string s4 (5, 's');
    
    cout << s3 << endl;
    //���Լ���� s1,s2,s4 
    return 0;
}
 
