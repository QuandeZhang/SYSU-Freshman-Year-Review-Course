void shift(int* a, int n, int d){
    int b[n];
    for (int i = 0; i < n; i++){
        b[i] = a[i];
    }
    int x = d % n;
    for (int i = 0; i < n; i++){
        a[(i+x)%n] = b[i];
    }
}