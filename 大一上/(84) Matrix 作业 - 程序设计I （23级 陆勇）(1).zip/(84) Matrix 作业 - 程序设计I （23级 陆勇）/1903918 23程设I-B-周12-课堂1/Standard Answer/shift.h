void shift(int *, int , int );
