void shift(int *A, int m, int n)
{
    int i;
    int B[1010];
    for (i = 0; i < m; i++)
        B[i] = A[i];
    for (i = 0; i < m; i++)
        A[(i+n)%m] = B[i];
}
