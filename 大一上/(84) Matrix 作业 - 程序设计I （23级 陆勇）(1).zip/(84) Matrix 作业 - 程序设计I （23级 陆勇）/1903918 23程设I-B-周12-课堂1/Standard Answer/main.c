#include<stdio.h>
#include "shift.h"

int main()
{
    int A[1010];
    int m, n, i;
    scanf("%d", &m);
    for (i = 0; i < m; i++)
        scanf("%d", &A[i]);
    scanf("%d", &n);
    shift(A, m, n);
    for (i = 0; i < m-1; i++)
        printf("%d ", A[i]);
    printf("%d\n", A[m-1]);
    return 0;
}

