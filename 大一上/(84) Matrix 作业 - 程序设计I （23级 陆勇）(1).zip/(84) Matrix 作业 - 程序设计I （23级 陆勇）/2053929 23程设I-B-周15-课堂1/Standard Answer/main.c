#include <stdio.h>
#include "head.h"

int main()
{
	char s[MAX_SIZE];

	/* Input string from user */
	scanf("%s", s);
	
    reserveDigits(s);
	reverseStr(s);

	printf("%s", s);
	return 0;
}