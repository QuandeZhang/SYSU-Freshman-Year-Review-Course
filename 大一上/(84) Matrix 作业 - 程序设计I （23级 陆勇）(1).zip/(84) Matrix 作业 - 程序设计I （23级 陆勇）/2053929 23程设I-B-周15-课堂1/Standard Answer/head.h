#pragma once
#define MAX_SIZE 100 // Maximum string size
void reserveDigits(char *s);
void reverseStr(char *s);