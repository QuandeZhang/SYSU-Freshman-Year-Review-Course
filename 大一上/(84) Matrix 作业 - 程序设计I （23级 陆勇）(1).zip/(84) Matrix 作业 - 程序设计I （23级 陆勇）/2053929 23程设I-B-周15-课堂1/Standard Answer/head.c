#include <stdio.h>
#include <string.h>
#include "head.h"

void reserveDigits(char *s){
    char *s1 = s, *s2 = s;
    while(*s1 != '\0'){
        if(*s1 <= '9' && *s1 >= '0'){
            *s2 = *s1;
            s2++;
        }
        s1++;
    }
    *s2 = '\0';
}

void reverseStr(char *s)
{
	int i = 0, len = strlen(s);
    if (len > 0)
    {
        for(i = 0; i < len / 2; i++){
            char tmp = *(s + i);
            *(s + i) = *(s + len - 1 - i);
            *(s + len - 1 - i) = tmp;
        }
    }
    else
    {
        char *s1 = "NoDigits";
        int i = 0, len = strlen(s1);
        for(i = 0; i < len; i++)
        {
            *(s + i) = *(s1 + i);
        }
        *(s + i) = '\0';
    }
}