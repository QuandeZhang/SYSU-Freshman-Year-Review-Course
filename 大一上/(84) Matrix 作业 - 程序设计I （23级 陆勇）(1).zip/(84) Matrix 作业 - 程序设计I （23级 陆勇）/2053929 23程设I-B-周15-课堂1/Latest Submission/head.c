void reserveDigits(char *s) {
    int i = 0, j = 0;
    while (s[i]) {
        if (s[i] >= '0' && s[i] <= '9') {
            s[j] = s[i];
            j++; 
        }
        i++;
    }
    while (j < i) s[j++] = 0;
}

void reverseStr(char *s) {
    if (!strlen(s)) {
        s[0] = 'N'; s[1] = 'o'; s[2] = 'D'; s[3] = 'i'; s[4] = 'g'; s[5] = 'i'; s[6] = 't'; s[7] = 's';
        // s = "NoDigits";
    }
    else {
        int j = 99;
    while (j && !s[j]) j--;
    int left = 0, right = j;
    while (left < right) {
        char c = s[left];
        s[left] = s[right];
        s[right] = c;
        left++;    right--;
    }
    }
    
}