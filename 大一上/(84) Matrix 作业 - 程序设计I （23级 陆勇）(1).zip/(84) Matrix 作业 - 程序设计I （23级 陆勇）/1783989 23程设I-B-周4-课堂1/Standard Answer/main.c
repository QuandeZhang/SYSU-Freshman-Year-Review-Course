#include<stdio.h>

int main(){
    printf("Hello sysu!");
    return 0;
}