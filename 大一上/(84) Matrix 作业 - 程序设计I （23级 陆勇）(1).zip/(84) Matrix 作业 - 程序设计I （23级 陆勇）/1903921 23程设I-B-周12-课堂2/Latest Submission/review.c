int review(int yesterdayWork,int remainWork){
    int read = 1, i = yesterdayWork+1, prev = 1;
    if (remainWork == 1) return 1;
    while (i++){
        prev = prev*2 + 1;
        read += prev;
        if (read >= remainWork) return i;
    }
}