# 23程设I-B-周12-课堂2

# Description

L同学有严重的拖延症，考试马上就要来了，但他还没有开始复习。于是，他决定从今天开始看ppt复习。虽然今天只看了一页，但他相信只要每天都复习前一天页数的两倍，并且再加一页，他就一定可以复习完。

根据ppt的总页数，以及考试之前可以抱佛脚的天数（包括今天），你认为L同学可以复习完吗，如果可以，他还能余下几天休息呢？

# Input format

输入只有一行，两个整数n，d。n表示ppt的总页数，d表示考试前还剩下几天（包括今天）。程序输入代码见main.c（已经写好）。
0 < n <= 2^31-1
0 < d <=35

# Output format

输出只有一行，表示能否休息及休息天数，具体输出格式见main.c（已经写好）。

# Sample Input1

2000 7

# Sample Output1

Never procrastinate again.

# Sample Input2

123456789 30

# Sample Output2

Of course! He is good at meeting deadlines, and still can relax for 4 days.

# Hint

1.本题**只需要完成对函数`review()`的定义**。在review.h中，函数已被声明为`int review(int yesterdayWork,int remainWork)`。请在review.c中，定义函数`review()`，让函数`review()`计算并返回复习所需的天数。
2.程序的输入输出已经在main.c中的`main()`函数内写好，**不需要实现输入输出**。
3.本题可以用循环来写，也可以尝试使用递归。

## 函数的参数及范围

函数有两个参数，含义如下：
1.`yesterdayWork`，表示前一天所复习的页数（如果使用递归，可以用到这个参数，也可以不用）。
当`main()`函数调用该函数时，参数`yesterdayWork`的值为0，因为L同学从今天才开始复习，昨天没有复习。

2.`remainWork`，表示在今天复习前，还有多少页没有复习。
当`main()`函数调用该函数时，参数`remainWork`的值为ppt的总页数。取值范围是0 <`remainWork` <= 2^31-1。

## 函数的返回值

当ppt的页数为`remainWork`时，**需要复习的天数**。

