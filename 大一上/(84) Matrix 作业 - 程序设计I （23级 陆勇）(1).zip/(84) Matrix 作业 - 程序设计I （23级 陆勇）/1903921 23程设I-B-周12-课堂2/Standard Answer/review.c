#include "review.h"

int review(int yesterdayWork,int remainWork)
{
    int todayWork=yesterdayWork*2+1;
    if(remainWork > todayWork)
        return 1+review(todayWork,remainWork-todayWork);
    else
        return 1;
}
