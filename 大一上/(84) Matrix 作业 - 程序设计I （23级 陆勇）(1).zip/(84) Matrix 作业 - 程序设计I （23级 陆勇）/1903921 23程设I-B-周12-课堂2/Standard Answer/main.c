#include<stdio.h>
#include "review.h"


int main()
{
    
    int n,d;
    scanf("%d%d",&n,&d);//输入复习页数n，剩余天数d

    int finishedDate = review(0,n);//调用函数review()，返回复习n页ppt所需要的天数finishedDate

    int remain = d-finishedDate;//计算复习后剩余的天数remain

    if(remain > 1)
        printf("Of course! He is good at meeting deadlines, and still can relax for %d days.\n", remain);
    else if(remain > 0)
        printf("Of course! He is good at meeting deadlines, and still can relax for %d day.\n", remain);
    else if (remain==0)
        printf("Of course! He is good at meeting deadlines, but no more time for relax.\n");
    else
        printf("Never procrastinate again.\n");

    return 0;
}
