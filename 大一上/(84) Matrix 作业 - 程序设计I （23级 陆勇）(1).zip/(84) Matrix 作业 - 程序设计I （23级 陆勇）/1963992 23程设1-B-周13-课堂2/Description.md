# 23程设1-B-周13-课堂2

# Description

给你两个字符串 `haystack` 和 `needle` (1<=长度<=100)，请你在 `haystack` 字符串中找出 `needle` 字符串的第一个匹配项的下标（下标从 0 开始）。如果 `needle` 不是 `haystack` 的一部分，则输出  `-1` 。

strlen()可以求一个字符串的长度，需要#include<string.h>

# Sample Input

```
sadbutsad
sad
```



# Sample Output

0
解释："sad"在下标 0 和 6 处匹配。第一个匹配项的下标是 0 ，所以输出 0

# Sample Input

```
hello
het
```

# Sample Output

-1
解释："het"没有在"hello"中出现，所以输出-1

