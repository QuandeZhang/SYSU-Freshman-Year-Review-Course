#include <stdio.h>
#include <string.h>
#include <stdbool.h>
int main(){
    char haystack[100];
    char needle[100];
    scanf("%s",haystack);
    scanf("%s",needle);
	int n = strlen(haystack), m = strlen(needle);
    bool have = false;
    for (int i = 0; i + m <= n; i++) {
        bool flag = true;
        for (int j = 0; j < m; j++) {
            if (haystack[i + j] != needle[j]) {
                flag = false;
                break;
            }
        }
        if (flag) {
            have =true;
            printf("%d",i);
            break;
        }
    }
    if(!have)
        printf("-1");

}