#include <stdio.h>
#include <string.h>

int main(){
    char str1[105], str2[105];
    scanf("%s%s", str1, str2);
    int d = strstr(str1, str2)-str1;
    if (d > strlen(str1)) printf("-1");
    else printf("%d", d);
    return 0;
}