void myshift(char *s) {
    int len = strlen(s);
    char ans[len];
    int i, j;
    for (i = 0, j = 0; i < len; i += 2) {
        ans[j++] = s[i];
    }
    int x, y;
    for (x = len - 1, y = len - 1; x > 0; x--) {
        if (x % 2) s[y--] = s[x];
    }
    for (i = 0; i < j; i++) {
        s[i] = ans[i];
    }
}