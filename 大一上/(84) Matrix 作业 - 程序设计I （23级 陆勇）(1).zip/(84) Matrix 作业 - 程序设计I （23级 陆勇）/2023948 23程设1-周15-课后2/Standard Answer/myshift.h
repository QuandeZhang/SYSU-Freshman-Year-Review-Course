#pragma once
void myshift(char *s);