#include <stdio.h>

int isRun(int x){
	if (x%100 == 0){
		if (x%400) return 0;
		return 1;
	}
	if (x%4 == 0) return 1;
	return 0;
}

int main() {
    int y, m, d, h;
    scanf("%d%d%d", &y, &m, &d);
    switch (m){
    	case 1:
    	case 3:
    	case 5:
    	case 7:
    	case 8:
    	case 10:
    	case 12:
    		if (d <= 31 && d >= 1) h = 1;
    		else h = 0;
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			if (d <= 30 && d >= 1)  h = 1;
			else h = 0;
			break;
		case 2:
			if (isRun(y)){
				if (d <= 29 && d >= 1) h = 1;
				else h = 0;
			}
			else {
				if (d <= 28 && d >= 1) h = 1;
				else h = 0;
			}
			break;
	}
	if (h) printf("日期合法");
	else printf("日期不合法");
	return 0; 
}