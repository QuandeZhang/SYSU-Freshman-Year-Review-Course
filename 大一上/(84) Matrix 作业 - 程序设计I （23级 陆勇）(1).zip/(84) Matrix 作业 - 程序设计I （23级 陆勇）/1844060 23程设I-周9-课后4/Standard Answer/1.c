#include <stdio.h>

int main() {
    int year, month, day;
    scanf("%d %d %d", &year, &month, &day);
    int isLeapYear = 0;  // 默认不是闰年
    if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
        isLeapYear = 1;  // 如果年份为闰年，标记为闰年
    }
    int valid = 1;  // 默认日期合法
    switch (month) {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            if (day < 1 || day > 31) {
                valid = 0;
            }
            break;
        case 4:
        case 6:
        case 9:
        case 11:
            if (day < 1 || day > 30) {
                valid = 0;
            }
            break;
        case 2:
            if (isLeapYear) {
                if (day < 1 || day > 29) {
                    valid = 0;
                }
            } else {
                if (day < 1 || day > 28) {
                    valid = 0;
                }
            }
            break;
        default:
            valid = 0;
            break;
    }
    if (valid) {
        printf("日期合法\n");
    } else {
        printf("日期不合法\n");
    }

    return 0;
}
