#include <stdio.h>
#include <string.h>
int main(){
    char s[100];
    scanf("%s", s);
    int i = strlen(s) - 1;
    while (s[i] == '\\' && i) {
        s[i] = '\0';
        i--;
    }
    printf("%s", s);
}