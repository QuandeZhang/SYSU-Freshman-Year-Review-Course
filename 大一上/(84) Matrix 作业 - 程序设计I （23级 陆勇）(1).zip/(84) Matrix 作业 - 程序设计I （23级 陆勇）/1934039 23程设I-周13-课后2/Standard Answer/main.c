#include <stdio.h>
#include <string.h>

void rtim(char s[]){
    int i = strlen(s);
    while(s[i-1]=='\\' && i-->0);
    s[i]='\0';
}

int main(){

    char str1[80];
    gets(str1);
    rtim(str1);
    printf("%s",str1);

}