int main() {
    char h1,h2,m1,m2;
    int t;
    scanf("%c%c%c%c%d",&h1,&h2,&m1,&m2,&t);
    int hour = (h1-'0')*10+(h2-'0');
    int minute = (m1-'0')*10+(m2-'0');
    int total_minutes = hour * 60 + minute - t;
    if (total_minutes < 0) {
        total_minutes += 1440;  // 24 hours in minutes
    }
    printf("%02d%02d\n", total_minutes / 60, total_minutes % 60);
    return 0;
}