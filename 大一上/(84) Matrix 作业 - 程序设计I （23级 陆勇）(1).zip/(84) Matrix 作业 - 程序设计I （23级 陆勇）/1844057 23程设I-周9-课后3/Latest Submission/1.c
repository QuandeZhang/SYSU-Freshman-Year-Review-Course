#include <stdio.h>

int main(){
	int h, m, t, p, x, y;
	scanf("%2d%2d%d", &h, &m, &p);
	t = 60 * h + m;
	t -= p;
	while (t < 0) t += 1440;
	x = t / 60;
	y = t % 60;
	printf("%02d%02d", x, y);
	return 0;
}