#include <stdio.h>

int main(){
	int n;
	scanf("%d", &n);
	
	n = (n >> 10) - (n >> 11 << 1) ;
	
	printf("%d", n);
	return 0;
}