#include <stdio.h>
#include <ctype.h>
#include <string.h>
void reverseWords(char* sentence) {
    int len = strlen(sentence);
    int i = 0, j = 0;
    while (j < len) {
        if (j == len-1 || isspace(sentence[j+1]) || ispunct(sentence[j+1])) {
            int x = i, y = j;
            while (x < y) {
                char tmp = sentence[x];
                sentence[x] = sentence[y];
                sentence[y] = tmp;
                x++;    y--;
            }
            j++;
            while (j < len && (isspace(sentence[j]) ||  ispunct(sentence[j]))) j++;
            i = j;
        } else j++;
    }
}

int main() {
    char sentence[200];
    // char c;
    // while (1) {
    //     scanf("%c", &c);
    //     if (c == EOF) break;
    //     sentence += c;
    // }
    gets(sentence);
    strcspn(sentence, "\n");
    reverseWords(sentence);
    printf("%s", sentence);
}
