int maxFood(int a[], int len);
