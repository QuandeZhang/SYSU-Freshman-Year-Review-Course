int maxFood(int a[], int len){
    int dp[len], i, ans = 0;
    for (i = 0; i < len; i++) dp[i] = 0;
    for (i = 0; i < len; i++){
        dp[i] = dp[i-1]+a[i] > a[i] ? dp[i-1]+a[i] : a[i];
        ans = dp[i] > ans ? dp[i] : ans;
    }
    return ans;
}