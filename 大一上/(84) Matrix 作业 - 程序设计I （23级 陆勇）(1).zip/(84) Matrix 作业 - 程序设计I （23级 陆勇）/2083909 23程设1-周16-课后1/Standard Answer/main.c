#include <stdio.h>

#define MAX_SIZE 51

void insertAndSort(int n, int a[], int *size);

int main() {
    int n;
    int a[MAX_SIZE];
    int size;

    // 获取要插入的数
    scanf("%d", &n);

    // 获取数组 a 的元素个数
    scanf("%d", &size);


    // 获取数组 a
    for (int i = 0; i < size; i++) {
        scanf("%d", &a[i]);
    }

    // 调用函数插入并排序
    insertAndSort(n, a, &size);

    // 输出插入并排序后的数组
    for (int i = 0; i < size; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");

    return 0;
}

void insertAndSort(int n, int a[], int *size) {
    int i = *size - 1;

    // 找到插入位置
    while (i >= 0 && a[i] > n) {
        a[i + 1] = a[i];
        i--;
    }

    // 插入数 n
    a[i + 1] = n;

    // 更新数组大小
    (*size)++;

    // 重新排序数组
    for (int j = 1; j < *size; j++) {
        int key = a[j];
        int k = j - 1;

        // 将比 key 大的元素向后移动
        while (k >= 0 && a[k] > key) {
            a[k + 1] = a[k];
            k--;
        }

        // 插入 key
        a[k + 1] = key;
    }
}
