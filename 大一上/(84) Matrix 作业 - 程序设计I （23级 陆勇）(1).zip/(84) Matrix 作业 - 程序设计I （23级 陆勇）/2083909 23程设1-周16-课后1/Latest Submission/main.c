#include <stdio.h>

void insertAndSort(int n, int a[], int *size) {
    a[*size] = n;
    int c = *size + 1;
    *size++;
    for (int i = 0; i < c; i++) {
        for (int j = 0; j < c; j++) {
            if (j && a[j] < a[j-1]) {
                int c = a[j];
                a[j] = a[j-1];
                a[j-1] = c;
            }
        }
    }
}

int main() {
    int n, size;
    int a[55];
    scanf("%d%d", &n, &size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &a[i]);
    }
    insertAndSort(n, a, &size);
    for (int i = 0; i < size + 1; i++) {
        printf("%d ", a[i]);
    }
}