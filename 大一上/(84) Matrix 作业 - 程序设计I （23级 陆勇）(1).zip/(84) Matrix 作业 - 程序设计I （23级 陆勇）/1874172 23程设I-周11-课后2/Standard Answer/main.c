#include <stdio.h>

// 获取巧克力的价格
float getChocolatePrice(char type, float weight) {
    if (type == 'A') {
        return 2.7 * weight;
    } else if (type == 'B') {
        return 3.8 * weight;
    }
}

// 计算总价格
float calculateTotalPrice(char type, float weight) {
    float pricePerChocolate = getChocolatePrice(type, weight);
    return pricePerChocolate;
}

int main() {
    char type;
    float weight;
    
    // 输入巧克力的种类和重量
    scanf(" %c %f", &type,&weight);
    
    // 计算总价格并输出结果
    float totalPrice = calculateTotalPrice(type, weight);
    printf("总价格为%.2f元", totalPrice);
    
    return 0;
}
