# 23程设I-周11-课后2

# 题目

学校自动贩卖机新进货了两种巧克力，分别是丝滑牛奶味的A牌巧克力和榛子可可味的B牌巧克力，一次仅能购买一种巧克力。请编写一个程序，包含多个函数：

1. ​`getChocolatePrice`​：接受两个参数，巧克力的种类和重量，返回对应巧克力的价格。A牌巧克力单价为2.7元/克，B牌巧克力单价为3.8元/克。
2. ​`calculateTotalPrice`：接受巧克力的种类和重量，以及`getChocolatePrice`函数返回的价格，返回购买这些巧克力的总价格（保留2位小数）。

# 输入

巧克力的种类和重量

# 输出

购买这些巧克力的总价

## 样例输入

```
A 15
```

## 样例输出

```
总价格为40.50元
```

### 提示

程序结构为：

```
// 获取巧克力的价格
float getChocolatePrice(char type, float weight) {
}

// 计算总价格
float calculateTotalPrice(char type, float weight) {
}

int main() {
}
```



