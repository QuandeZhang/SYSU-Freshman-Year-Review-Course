#include <stdio.h>
// 获取巧克力的价格
float getChocolatePrice(char type, float weight) {
	if (type=='A') return 2.7;
	return 3.8;
}

// 计算总价格
float calculateTotalPrice(char type, float weight) {
	return weight * getChocolatePrice(type, weight);
}

int main() {
	float weight;
	char type;
	scanf("%c%f", &type, &weight);
	printf("总价格为%.2f元", calculateTotalPrice(type, weight));
	return 0;
}