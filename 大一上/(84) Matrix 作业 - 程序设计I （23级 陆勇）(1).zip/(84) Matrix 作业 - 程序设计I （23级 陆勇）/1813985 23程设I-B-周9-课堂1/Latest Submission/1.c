#include <stdio.h>
int main() {
    int a, b;
    scanf("%d%d", &a, &b);
    if (a == 0) printf("12:%02d AM", b);
    else if (a < 12) printf("%d:%02d AM", a, b);
    else if (a == 12) printf("%d:%02d PM", a, b);
	else if (a > 12) printf("%d:%02d PM", a-12, b);
	return 0; 
}