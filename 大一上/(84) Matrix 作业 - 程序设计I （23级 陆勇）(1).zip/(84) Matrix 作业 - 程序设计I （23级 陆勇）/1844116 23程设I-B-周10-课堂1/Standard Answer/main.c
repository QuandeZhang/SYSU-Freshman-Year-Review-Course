#include<stdio.h>
int main(){
    int n = 0;
    double f = 0;
    scanf("%d", &n);
    for(; n > 0; n--) f = (f+1) * 1.01;
    printf("%.2lf", f);
    return 0;
}