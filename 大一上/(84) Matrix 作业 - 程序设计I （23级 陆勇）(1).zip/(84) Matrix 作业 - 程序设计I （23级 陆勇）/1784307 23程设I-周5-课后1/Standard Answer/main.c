#include <stdio.h>
#include <math.h>
int main(){
	double a,c,e,g;
    int b,d,f,h;
	scanf("%lf %d %lf %d %lf %d %lf %d",&a,&b,&c,&d,&e,&f,&g,&h);
	printf("%.2lf\n",a*b+c*d+e*f+g*h);
}
