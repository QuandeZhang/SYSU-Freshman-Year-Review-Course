#include <stdio.h>

int main(){
	double a, sum = 0;
	int b, n  = 4;
	while(n--){
		scanf("%lf %d", &a, &b);
		sum += a * b;
	}
	printf("%.2lf", sum);
	return 0;
}