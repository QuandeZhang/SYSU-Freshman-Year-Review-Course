#include<stdio.h>
int main()
{
    int a;
    scanf("%d",&a);
    printf("%X\n%o",a,a);
    return 0;
}