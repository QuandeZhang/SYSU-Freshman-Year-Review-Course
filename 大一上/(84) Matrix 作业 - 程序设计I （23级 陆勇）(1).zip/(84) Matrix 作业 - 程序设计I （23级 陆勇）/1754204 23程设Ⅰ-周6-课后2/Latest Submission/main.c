#include <stdio.h>

int main(){
	int n;
	scanf("%d", &n);
	printf("%X\n%o", n, n);
	return 0;
}