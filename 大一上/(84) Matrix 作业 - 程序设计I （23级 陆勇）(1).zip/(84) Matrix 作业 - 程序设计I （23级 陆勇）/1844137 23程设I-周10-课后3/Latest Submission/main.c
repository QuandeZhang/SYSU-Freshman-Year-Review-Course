#include <stdio.h>

int main()
{
	int i, x;
	int w[5];
	for (i = 0; i < 5; i++) 
		scanf("%d", &w[i]);
	i = 0;
	while (1){
		scanf("%d", &x);
		if (x == -1) break;
		if (x == w[i]) i++;
		if (i == 5) break;
	}
	if (i == 5) printf("1");
	else printf("0");
	return 0;
}