#include<stdio.h>
int main(){
    int w = 0;
    for(int i = 0, w_i = 0; i < 5; i++){
        scanf("%d", &w_i);
        w = w / 10 + w_i * 10000;
    }
 
    for(int p_i = 0;p_i != -1;scanf("%d", &p_i)){
        if(p_i == w % 10) w = w/10;
    }

    printf("%d", (int)(w == 0));
    return 0;
}