#include<stdio.h>
int main()
{
    int in1,in2,in3,in4,in5,in6,in7,in8,in9;
    scanf("%d%d%d",&in1,&in2,&in3);
    scanf("%d%d%d",&in4,&in5,&in6);
    scanf("%d%d%d",&in7,&in8,&in9);
    double res1 = (double)(in1+in2+in3);
    double res2 = (double)(in4+in5+in6);
    double res3 = (double)(in7+in8+in9);
    double res4 = (res1+res2+res3)/3;
    double res5 = (double)(in1+in4+in7)/3;
    double res6 = (double)(in2+in5+in8)/3;
    double res7 = (double)(in3+in6+in9)/3;
    printf("%.2lf %.2lf %.2lf\n",res1,res2,res3,res4);
    printf("%.2lf %.2lf %.2lf %.2lf",res4,res5,res6,res7);
    return 0;
}