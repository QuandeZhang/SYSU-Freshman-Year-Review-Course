#include <stdio.h>

int main(){
	int a[3][3], sum = 0, sumA = 0;
	double avg;
	for (int i = 0; i < 3; i++){
		for (int j = 0; j < 3; j++){
			scanf("%d", &a[i][j]);
			sum += a[i][j];
		}
		avg = 1.0 * sum;
		sumA += sum;
		printf("%.2lf ", avg);
		sum = 0; 
	}
	puts("");
	avg = 1.0 * sumA / 3;
	printf("%.2f ", avg);
	for (int x = 0; x < 3; x++){
		sum = 0;
		for (int y = 0; y < 3; y++) {
			sum += a[y][x];
		}
		avg = 1.0 * sum / 3;
		printf("%.2lf ", avg);
	}
}
	