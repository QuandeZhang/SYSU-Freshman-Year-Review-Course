#include <stdio.h>
#include <string.h>

void strPartCopy(char *dest, char *source){
    int i=0;
    int len = strlen(source);
    for(i=0;i<len;i+=2,source+=2,dest++)
        *dest = *source;
    *dest = '\0';
}

int main(){
    char str1[81],str2[81];
    gets(str1);
    strPartCopy(str2,str1);
    printf("%s",str2);
}

