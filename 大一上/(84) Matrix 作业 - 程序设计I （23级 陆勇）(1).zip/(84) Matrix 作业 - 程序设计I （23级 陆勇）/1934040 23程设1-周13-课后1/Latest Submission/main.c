#include <stdio.h>
#include <string.h>
int main(){
    char s[100], ans[100] = "";
    scanf("%s", s);
    int j = 0;
    for (int i = 0; i < strlen(s); i += 2){
        ans[j++] = s[i];
    }
    ans[j] = '\0';
    printf("%s", ans);
}