void evenReverse(char* s) {
    int j = 104;
    while (!s[j] && j) j--;
    int left = 0;
    int right;
    if (j % 2) right = j - 1;
    else right = j;
    while (left < right) {
        char c = s[left];
        s[left] = s[right];
        s[right] = c;
        left += 2;
        right -= 2;
    }
}