#include <stdio.h>
#include <string.h>
#include "evenReverse.h"

void evenReverse(char* s){
    int len=strlen(s);
    if(len<=2)
    return;

    int i=0;
    int j=(len-1)%2==0?(len-1):len-2;

    while(i<j){
        char c=s[i];
        s[i]=s[j];
        s[j]=c;
        i+=2;
        j-=2;
    }
}