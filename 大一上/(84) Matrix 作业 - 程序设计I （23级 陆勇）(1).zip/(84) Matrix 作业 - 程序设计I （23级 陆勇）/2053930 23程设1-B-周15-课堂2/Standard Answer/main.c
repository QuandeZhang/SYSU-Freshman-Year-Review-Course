#include <stdio.h>
#include <string.h>
#include "evenReverse.h"

int main(){
    char s[105];
    scanf("%s",s);
    evenReverse(s);
    printf("%s",s);
    return 0;
}