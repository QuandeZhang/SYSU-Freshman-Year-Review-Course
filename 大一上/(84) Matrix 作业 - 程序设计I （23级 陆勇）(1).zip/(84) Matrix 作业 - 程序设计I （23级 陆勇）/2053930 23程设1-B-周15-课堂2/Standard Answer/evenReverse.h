#pragma once
void evenReverse(char* s);