#include "ListNode.h"

// 递归版本，比较简洁
struct ListNode* mergeTwoLists(struct ListNode* list1, struct ListNode* list2) {
    if (list1 == NULL)   return list2;
    if (list2 == NULL)   return list1;

    if (list1->val < list2->val) {
        list1->next = mergeTwoLists(list1->next, list2);
        return list1;
    } else {
        list2->next = mergeTwoLists(list1, list2->next);
        return list2;
    }
}

/* 
循环版本，且不开新结点
struct ListNode* mergeTwoLists(struct ListNode* list1, struct ListNode* list2) {
    if (list1 == NULL)   return list2;
    if (list2 == NULL)   return list1;

    struct ListNode *head1 = list1, *head2 = list2, *cur_head = NULL;
    if (head1->val < head2->val) {
        cur_head = head1;
        head1 = head1->next;
    } else {
        cur_head = head2;
        head2 = head2->next;
    }
    struct ListNode *final_head = cur_head;

    while (head1 && head2) {
        if (head1->val < head2->val) {
            cur_head->next = head1;
            head1 = head1->next;
        } else {
            cur_head->next = head2;
            head2 = head2->next;
        }
        cur_head = cur_head->next;
    }

    cur_head->next = head1 ? head1 : head2;
    return final_head;
}
 */