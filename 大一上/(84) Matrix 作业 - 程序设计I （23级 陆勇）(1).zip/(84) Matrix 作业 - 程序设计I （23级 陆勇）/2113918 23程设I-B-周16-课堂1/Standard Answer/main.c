#include <stdio.h>
#include <string.h>

void sortByLength(char *strArray[], int numStrings) {
    // 使用冒泡排序对字符串数组按长度进行升序排序
    for (int i = 0; i < numStrings - 1; i++) {
        for (int j = 0; j < numStrings - i - 1; j++) {
            if (strlen(strArray[j]) > strlen(strArray[j + 1])) {
                // 交换字符串指针
                char *temp = strArray[j];
                strArray[j] = strArray[j + 1];
                strArray[j + 1] = temp;
            }
        }
    }
}

int main() {
    int numStrings;

    // 输入字符串数量
    scanf("%d", &numStrings);

    char *strArray[numStrings];
    char inputString[100]; // 用于存储每行输入的字符串

    // 输入字符串
    for (int i = 0; i < numStrings; i++) {
        scanf("%s", inputString);
        // strArray[i] = strdup(inputString); // 使用strdup复制字符串，确保字符串的生命周期足够长
        strArray[i] = (char*)malloc(sizeof(char) * 100);
        strcpy(strArray[i], inputString);
    }

    // 调用排序函数
    sortByLength(strArray, numStrings);

    // 输出排序后的字符串数组
    for (int i = 0; i < numStrings; i++) {
        printf("%s\n", strArray[i]);
        free(strArray[i]); // 必须free
        strArray[i] = NULL; // 置空野指针
    }

    return 0;
}
