#include <stdio.h>
#include <string.h>
    

int main() {
    int numStrings;
    scanf("%d", &numStrings);
    char strArray[numStrings][100];
    for (int i = 0; i < numStrings; i++) {
    	scanf("%s", strArray[i]);
    }
    for (int i = 0; i < numStrings; i++) {
        for (int j = 1; j < numStrings; j++) {
            if (strlen(strArray[j]) < strlen(strArray[j-1])) {
                char tmp[100];
                for (int k = 0; k < 100; k++) {
                    tmp[k] = strArray[j][k];
                }
                for (int k = 0; k < 100; k++) {
                    strArray[j][k] = strArray[j-1][k];
                }
                for (int k = 0; k < 100; k++) {
                    strArray[j-1][k] = tmp[k];
                }
            }
        }
    }
    for (int j = 0; j < numStrings; j++) {
        printf("%s\n", strArray[j]);
    }
}