# 23程设I-B-周16-课堂1

# 题目描述

设计一个程序，实现对输入字符串数组按字符串长度进行排序功能。具体要求如下：

1. 编写函数`void sortByLength(char *strArray[], int numStrings);`，用于对输入的字符串数组      **strArray** 按字符串长度进行升序排序。
2. 在主程序中，接受用户输入的字符串数组，然后调用函数进行排序。
3. 输出排序后的字符串数组。

说明：相同长度的字符串排序按照输入顺序排序

# 示例输入1：

4

Apple

Banana

Orange

Grapes

# 示例输出1：

Apple

Banana

Orange

Grapes


