#include <stdio.h>

typedef struct Table {
    char class[20];
    int start, end;
} table;

int main() {
    int n;
    scanf("%d", &n);
    if (n == 0) {
        printf("QiDong\n");
        return 0;
    }
    table t[n];
    for (int i = 0; i < n; i++) {
        scanf("%s%d%d", &t[i].class, &t[i].start, &t[i].end);
    }
    for (int i = 0; i < n; i++) {
        for (int j = 1; j < n; j++) {
            if (t[j-1].start > t[j].start) {
                table tmp = t[j];
                t[j] = t[j-1];
                t[j-1] = tmp;
            }
        }
    }
    for (int i = 0; i < n; i++) {
        printf("%02d:00 ~ %02d:00 : %s\n", t[i].start, t[i].end, t[i].class);
    }
}