#include <stdio.h>

struct node {
    char class_name[20];
    int start;
    int end;
};

void swap(struct node* a, struct node* b) {
    struct node tmp = *a;
    *a = *b;
    *b = tmp;
}

void sort(struct node classes[], int n) {
    for (int i = 0; i < n; ++i) {
        for (int j = i + 1; j < n; ++j) {
            if (classes[i].start > classes[j].start)
                swap(&classes[i], &classes[j]);
        }
    }
}

int main() {
    int n;
    scanf("%d", &n);

    if (n == 0) {
        puts("QiDong");
        return 0;
    }

    struct node classes[50];
    for (int i = 0; i < n; ++i)
        scanf("%s%d%d", classes[i].class_name, &classes[i].start, &classes[i].end);
    
    sort(classes, n);

    for (int i = 0; i < n; ++i)
        printf("%02d:00 ~ %02d:00 : %s\n", classes[i].start, classes[i].end, classes[i].class_name);

    return 0;
}
