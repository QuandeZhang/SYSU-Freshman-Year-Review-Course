#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);//输入n 
 
	if(n%2==0){ //若n对2取余为0则n为偶数，否则n为奇数，注意判断条件要用== 
		printf("even\n");//输出偶数 
	}else{
		printf("odd\n");//输出奇数 
	}
}