#include <stdio.h>

int main() {
    int a00, a01, a02,
        a10, a11, a12,
        a20, a21, a22;
    int out;
    scanf("%d%d%d%d%d%d%d%d%d",
        &a00, &a01, &a02,
        &a10, &a11, &a12,
        &a20, &a21, &a22
    );
    out = a00*a00+a01*a01+a02*a02+a10*a10+a11*a11+a12*a12+a20*a20+a21*a21+a22*a22;
    printf("%d\n",out);
    return 0;
}
