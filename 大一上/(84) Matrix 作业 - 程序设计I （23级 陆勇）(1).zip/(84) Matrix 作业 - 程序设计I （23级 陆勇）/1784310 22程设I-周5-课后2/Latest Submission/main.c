#include <stdio.h>

int main(){
	int n = 9, i, sum = 0;
	while (n--){
		scanf("%d", &i);
		sum += i*i;
	}
	printf("%d", sum);
	return 0;
}
