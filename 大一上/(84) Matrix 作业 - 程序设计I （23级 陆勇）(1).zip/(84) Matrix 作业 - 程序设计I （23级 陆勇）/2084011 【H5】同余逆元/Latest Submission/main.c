#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);
    while (n--) {
        long long int a, m, i, flag = 1;
        scanf("%lld%lld", &a, &m);
        for (i = 1; i < m && i <= a; i++) {
            if (a * i % m == 1) {
                flag = 0;
                printf("%lld\n", i);
                break;
            }
        }
        if (flag) printf("false\n");
    }
}