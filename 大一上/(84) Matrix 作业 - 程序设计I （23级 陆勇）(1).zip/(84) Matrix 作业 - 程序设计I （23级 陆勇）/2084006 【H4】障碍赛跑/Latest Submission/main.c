#include <stdio.h>

int main() {
    int n, m, a, b, prev = 0;
    double T, c, ans = 0;
    scanf("%d%d%lf", &n, &m, &T);
    while (m--) {
        scanf("%d%d%lf", &a, &b, &c);
        ans += (a - prev) * T + (b - a) * c;
        prev = b;
    }
    ans += (n - prev) * T;
    printf("%.2lf", ans);
    return 0;
}