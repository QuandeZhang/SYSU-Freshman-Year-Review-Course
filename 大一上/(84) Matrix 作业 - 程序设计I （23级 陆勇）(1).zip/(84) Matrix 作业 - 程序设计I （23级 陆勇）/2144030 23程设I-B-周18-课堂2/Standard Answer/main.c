#include<stdio.h>
int main() {
    int a, b, c;
    int money, number, flag;
    scanf("%d %d", &money, &number);
    flag = 0;
    for (a = money/5; a >= 0; a--)
        for (b = money/3; b >= 0; b--)
            for (c = money; c >= 0; c--) {
                if (a + b + c*3 == number && a*5 + b*3 + c == money) {
                        flag++;
                        printf("%d %d %d\n", a, b, c*3);
                    }
            }
    if ( flag == 0 )
        printf("no answer\n");
    return 0;
}