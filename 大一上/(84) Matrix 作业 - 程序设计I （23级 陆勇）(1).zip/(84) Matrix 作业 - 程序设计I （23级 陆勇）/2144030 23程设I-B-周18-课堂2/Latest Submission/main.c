#include <stdio.h>

int main() {
    int m, n, flag = 1;
    scanf("%d%d", &m, &n);
    for (int i = m / 5; i >= 0; i--) {
        for (int j = m / 3; j >= 0; j--) {
            for (int k = m; k >= 0; k--) {
                if (i + j + 3 * k == n && i * 5 + j * 3 + k == m) {
                    printf("%d %d %d\n", i, j, 3 * k);
                    flag = 0;
                }
            }
        }
    }
    if (flag) printf("no answer");
    return 0;
}