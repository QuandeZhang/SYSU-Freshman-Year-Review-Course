# 23程设I-周13-课后3

编写一个函数 reverse，将输入的字符串进行反转后输出，如“abcd”反转为“dcba”。字符串长度不超过80。

输入：
abcdef

输出：
fedcba



