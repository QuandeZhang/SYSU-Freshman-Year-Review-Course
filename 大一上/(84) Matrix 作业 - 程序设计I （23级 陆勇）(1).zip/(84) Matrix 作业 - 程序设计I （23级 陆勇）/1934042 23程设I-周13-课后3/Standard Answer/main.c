#include <stdio.h>
#include <math.h>
#include <string.h>

void reverse(char str[]){
    char t;
    int i,j;
    int len = strlen(str);

    for(i=0,j=len;i<len/2;i++,j--){
        t = str[i];
        str[i] = str[j-1];
        str[j-1] = t;
    }
}

int main(){
    char str1[80];
    gets(str1);

    reverse(str1);
    puts(str1);
    return 0;
}