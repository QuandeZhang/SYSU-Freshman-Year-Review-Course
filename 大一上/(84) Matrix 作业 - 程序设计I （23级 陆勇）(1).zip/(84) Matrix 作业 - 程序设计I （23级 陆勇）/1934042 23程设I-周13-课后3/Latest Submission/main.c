#include <stdio.h>
#include <string.h>
int main(){
    char s[100], a[100];
    scanf("%s", s);
    for (int i = 0; i < strlen(s); i++){
        a[strlen(s)-i-1] = s[i];
    }
    a[strlen(s)] = '\0';
    printf("%s", a);
}