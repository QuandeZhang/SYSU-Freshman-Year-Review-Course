#include <stdio.h>

int main(){
	float a, b, c;
	scanf("%f%f%f", &a, &b, &c);
	double d = (a + b + c) / 3;
	printf("%.3lf\n", d);
	
	double x, y, z;
	scanf("%lf%lf%lf", &x, &y, &z);
	double i = (x + y + z) / 3;
	printf("%.3lf", i);
	return 0;
}