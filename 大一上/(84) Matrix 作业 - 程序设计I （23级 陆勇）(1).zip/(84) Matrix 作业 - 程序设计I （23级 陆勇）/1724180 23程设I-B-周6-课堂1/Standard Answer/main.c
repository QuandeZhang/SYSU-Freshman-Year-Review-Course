int main(void){
    float a, b, c;
    double d, e, f;
    scanf("%f %f %f", &a, &b, &c);
    scanf("%lf %lf %lf", &d, &e, &f);
    float result = (a + b + c) / 3;
    double result2 = (d + e+ f) /3;
    printf("%.3f\n%.3lf", result, result2);
    return 0;
}