#include <stdlib.h>
#include "ListNode.h"
int getValue(struct ListNode* head, int index) {
    struct ListNode* cur = head->next;
    while (cur && index--) {
        cur = cur->next;
    }
    if (cur) return cur->val;
    return 0;
}

int addAtIndex(struct ListNode* head, int index, int value) {
    struct ListNode* cur = head;
    int ans = 0;
    while (cur && index--) {
        cur = cur->next;
    }
    if (cur) {
        struct ListNode* newNode = (struct ListNode*)malloc(sizeof(struct ListNode));
        newNode->val = value;
        newNode->next = cur->next;
        cur->next = newNode;
        ans = 1;
    }
    return ans;
}

int deleteAtIndex(struct ListNode* head, int index) {
    struct ListNode* cur = head;
    int ans = 0;
    while (cur && index--) {
        cur = cur->next;
    }
    if (cur && cur->next) {
        struct ListNode* tmp = cur->next;
        cur->next = tmp->next;
        ans = tmp->val;
        free(tmp);
        tmp = NULL;
    }
    return ans;
}

void reverseList(struct ListNode* head) {
    struct ListNode* left = head->next;
    if (!left) return;
    struct ListNode* right = left->next;
    left->next = NULL;
    while (right) {
        struct ListNode* next = right->next;
        right->next = left;
        left = right;
        right = next;
    }
    head->next = left;
}

void reverseIndex(struct ListNode* head, int left, int right) {
    if (left >= right) return;
    struct ListNode* start = head; 
	struct ListNode* end = head->next;
	
    while (end && right--) end = end->next;
	if (!end) return;
	while (left--) start = start->next;
	
	struct ListNode* cur1 = start->next;
	if (!cur1) return;
	struct ListNode* cur2 = cur1->next;
	
	start->next = end;
	cur1->next = end->next;
	end = end->next;
	while (cur2 != end) {
		struct ListNode* tmp = cur2->next;
		cur2->next = cur1;
		cur1 = cur2;
		cur2 = tmp;
	}
	return;
}

void printList(struct ListNode* head) {
    struct ListNode* cur = head;
    while (cur) {
        printf("%d -> ", cur->val);
        cur = cur->next;
    }
    printf("null\n");
}

void freeList(struct ListNode* head) {
    while (head) {
        struct ListNode* tmp = head;
        head = head->next;
        free(tmp);
        tmp = NULL;
    }
}