# 23程设I-周17-课后2

# 题目描述

实现一个链表及相关函数，链表节点的下标从 **0** 开始，需要实现的函数如下：

+ `int getValue(struct ListNode* head, int index);` 获取链表下标为`index`的节点的值，若下标无效返回`0`。
+ `int addAtIndex(struct ListNode* head, int index, int val);`将一个值为`val`的节点插入到下标为`index`的节点前。若下标等于链表长度，则将节点插入链表尾。如下标大于链表长度，则插入失败。插入成功返回`1`，插入失败返回`0`。
+ `int deleteAtIndex(struct ListNode* head, int index);`若存在下标为`index`的节点，删除该节点，否则删除失败。删除成功返回删除节点的值，删除失败返回`0`。
+ `void reverseList(struct ListNode* head);`反转整个链表。
+ `void reverseIndex(struct ListNode* head, int left, int right);`反转从下标为`left`到下标为`right`的节点，包括这两个节点。若下标不合理，则不反转。保证`left<=right`。
+ `void printList(struct ListNode* head);`打印链表，有三个节点的链表打印结果: `val1 -> val2 -> val3 -> null`，结尾有换行符。
+ `void freeList(struct ListNode* head);`释放链表内存。

链表反转部分尽量使用O(1)的辅助空间，不要借助数组实现。
保证链表中每个节点`val`大于`0`。

# 输入描述

第一行输入正整数`n`，代表程序需要执行的操作数。
接下来`n`行，每行包含字符串`s`(操作种类)及操作需要的参数。

`1 <= n <= 1000`

# 样例输入

```c
21
addAtIndex 0 1
addAtIndex 0 2
addAtIndex 3 2
getValue 2
getValue 1
deleteAtIndex 0
deleteAtIndex 1
addAtIndex 1 3
addAtIndex 2 4
addAtIndex 2 5
addAtIndex 1 8
reverseIndex 0 3
reverseIndex 1 3
reverseIndex 0 5
reverseList
getValue 2
getValue 5
deleteAtIndex 1
reverseIndex 2 3
reverseIndex 1 1
reverseList
```

# 样例输出

```c
addAtIndex: add 1 at 0
addAtIndex: add 2 at 0
addAtIndex: fail
getValue: fail
getValue: get 1
deletaAtIndex: delete 2 at 0
deleteAtIndex: fail
addAtIndex: add 3 at 1
addAtIndex: add 4 at 2
addAtIndex: add 5 at 2
addAtIndex: add 8 at 1
5 -> 3 -> 8 -> 1 -> 4 -> null
5 -> 1 -> 8 -> 3 -> 4 -> null
5 -> 1 -> 8 -> 3 -> 4 -> null
4 -> 3 -> 8 -> 1 -> 5 -> null
getValue: get 8
getValue: fail
deletaAtIndex: delete 3 at 1
4 -> 8 -> 5 -> 1 -> null
4 -> 8 -> 5 -> 1 -> null
1 -> 5 -> 8 -> 4 -> null

1 -> 5 -> 8 -> 4 -> null
```

