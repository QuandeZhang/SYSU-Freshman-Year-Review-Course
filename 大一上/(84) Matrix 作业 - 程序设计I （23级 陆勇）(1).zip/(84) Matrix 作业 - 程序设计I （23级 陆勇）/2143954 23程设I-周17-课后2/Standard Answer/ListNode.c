#include <stdio.h>

#include "ListNode.h"

int getValue(struct ListNode* head, int index) {
	struct ListNode* curr = head->next;
	while (curr != NULL && index != 0) {
		curr = curr->next;
		index--;
	}
	
	return curr ? curr->val : 0;
}

int addAtIndex(struct ListNode* head, int index, int val) {
	struct ListNode* prev = head;
	struct ListNode* curr = head->next;
	
	while(curr != NULL && index != 0) {
		prev = curr;
		curr = curr -> next;
		index--;
	}
	
	if (curr == NULL && index != 0) {
		return 0;
	}
	
	struct ListNode* newNode = (struct ListNode*)malloc(sizeof(struct ListNode));
	newNode->val = val;
	prev->next = newNode;
	newNode->next = curr;
	return 1;
}

int deleteAtIndex(struct ListNode* head, int index) {
	struct ListNode* prev = head;
	struct ListNode* curr = head->next;
	
	while(curr != NULL && index != 0) {
		prev = curr;
		curr = curr -> next;
		index--;
	}
	
	if (curr == NULL) {
		return 0;
	}
	
	prev->next = curr->next;
	int res = curr->val;
	free(curr);
	return res;
}

void reverseList(struct ListNode* head) {
	if (head->next == NULL) return;
	
	struct ListNode* prev = NULL;
	struct ListNode* curr = head->next;
	struct ListNode* last = curr->next;
	
	while(last != NULL) {
		curr->next = prev;
		prev = curr;
		curr = last;
		last = last->next;
	}
	curr->next = prev;
	head->next = curr;
}

void reverseIndex(struct ListNode* head, int left, int right) {
	struct ListNode* rightNode = head->next;
	while (rightNode != NULL && right != 0) {
		rightNode = rightNode->next;
		right--;
	}
	
	if (rightNode == NULL) return;
	
	struct ListNode* leftNode = head->next;
	struct ListNode* prev = head;
	while(leftNode != NULL && left != 0) {
		prev = leftNode;
		leftNode = leftNode->next;
		left--;
	} 
	
	struct ListNode* last = rightNode->next;
	rightNode->next = NULL;
	
	reverseList(prev);
	leftNode->next = last;
}

void printList(struct ListNode* head) {
	while(head != NULL) {
		printf("%d -> ", head->val);
		head = head->next;
	}
	printf("null\n");
}

void freeList(struct ListNode* head) {
	while(head != NULL) {
		struct ListNode* curr = head;
		head = head->next;
		free(curr);
	}
}