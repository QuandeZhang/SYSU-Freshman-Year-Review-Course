# 23程设I-B-周4-课堂2

## 题目

输出以下两行字符
first line
second line

## 输出样例

```
first line
second line
```

