#include <stdio.h>

int main(){
	printf("first line\n");
	printf("second line");
	return 0;
} 