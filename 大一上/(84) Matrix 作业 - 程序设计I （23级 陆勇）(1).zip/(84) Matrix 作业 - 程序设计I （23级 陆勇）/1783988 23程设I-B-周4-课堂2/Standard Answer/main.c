#include <stdio.h>

int main(){
    printf("first line\nsecond line");
    return 0;
}