#include <stdio.h>
#include <stdbool.h>

int main(){
	long long n, i, x, e = 0, s = 600;
	scanf("%d", &n);
	for (i = 0; i < n; i++){
		scanf("%d", &x);
		if (x){
			if (e > 2) e = 2;
			if (e < -2) e = -2;
			if (s < 0) s = 0;
			if (s > 750) s = 750;
			s += e;
			e--; 
			if (e > 2) e = 2;
			if (e < -2) e = -2;
			if (s < 0) s = 0;
			if (s > 750) s = 750;
		}
		else {
			if (e > 2) e = 2;
			if (e < -2) e = -2;
			if (s < 0) s = 0;
			if (s > 750) s = 750;
			e = 2;
			s--;	
			if (e > 2) e = 2;
			if (e < -2) e = -2;
			if (s < 0) s = 0;
			if (s > 750) s = 750;
		}
	}
	if (s < 0) s = 0;
	if (s > 750) s = 750;
	printf("%d", s);
	return 0;
}