#include<stdio.h>
int main(){
    int n, g = 600, s = 0, a = 0;
    scanf("%d", &n);
    for(; n > 0; n--){
        scanf("%d", &a);

        switch(a){
            case 0:
                g--;
                s = 2;
                break;
            case 1:
                g += s;
                s--;
        }

        g = g < 750 ? (g > 0 ? g : 0) : 750;
        s = s < 2 ? (s > -2 ? s : -2) : 2;
    }
    printf("%d", g);
    return 0;
}