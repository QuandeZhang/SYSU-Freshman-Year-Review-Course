#include <stdio.h>

int main() {
    char unit;
    double temperature;
    scanf("%lf%c", &temperature, &unit);
    if (unit == 'C') {
        double fahrenheit = (temperature * 9/5) + 32;
        printf("%.2lfF\n", fahrenheit);
    }
    else if (unit == 'F') {
        double celsius = (temperature - 32) * 5/9;
        printf("%.2lfC\n", celsius);
    }
    return 0;
}