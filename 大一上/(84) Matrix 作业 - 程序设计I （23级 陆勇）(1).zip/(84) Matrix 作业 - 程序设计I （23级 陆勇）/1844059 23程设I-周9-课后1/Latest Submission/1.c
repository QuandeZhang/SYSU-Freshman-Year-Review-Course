#include <stdio.h>
#include <string.h>

int main(){
	double i, ans;
	char x;
	scanf("%lf%c", &i, &x);
	if (x == 'C') {
		ans = (i * 9 / 5) + 32;
		printf("%.2lfF", ans); 
	}
	else{
		ans = (i - 32) * 5 / 9;
		printf("%.2lfC", ans);
	}
	return 0;
}