#include<stdio.h>
int main()
{
    double in1,in2,in3,in4,in5,in6,in7,in8,in9;
    scanf("%lf%lf%lf",&in1,&in2,&in3);
    scanf("%lf%lf%lf",&in4,&in5,&in6);
    scanf("%lf%lf%lf",&in7,&in8,&in9);
    double res1 = (in1+in2+in3)/3;
    double res2 = (in4+in5+in6)/3;
    double res3 = (in7+in8+in9)/3;
    printf("%.4f %.4f %.4f",res1,res2,res3);
    return 0;
}