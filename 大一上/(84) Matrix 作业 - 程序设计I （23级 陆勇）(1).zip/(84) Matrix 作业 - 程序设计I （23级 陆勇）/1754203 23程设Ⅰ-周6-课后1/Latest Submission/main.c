#include <stdio.h>
#define t 3
int main(){
	double sum = 0, a;
	for (int i = 0; i < t; i++){
		sum = 0;
		for (int j = 0; j < t; j++){
			scanf("%lf", &a);
			sum += a;
		}
		a = sum / 3;
		printf("%.4lf ", a);
	}
	return 0;
}