void merge(int *arr, int start, int mid, int end) {
    int tmp[end - start + 1];

    for (int i = 0; i <= end - start; i++) tmp[i] = 0;
    int i = start, j = mid + 1;
    for (int k = 0; k <= end - start; k++) {
        if (i <= mid && j <= end) {
            if (arr[i] < arr[j]) tmp[k] = arr[i++];
            else tmp[k] = arr[j++];
        } else if (i <= mid) tmp[k] = arr[i++];
        else if (j <= end) tmp[k] = arr[j++];
    }
    for (int k = 0; k <= end - start; k++) {
        arr[k + start] = tmp[k];
    }
}
void mergeSort(int *arr, int start, int end) {
    int mid = start;
    if (start < end) {
        mid = (end - start) / 2 + start;
        mergeSort(arr, start, mid);
        mergeSort(arr, mid + 1, end);
        merge(arr, start, mid, end);
    }
    // merge(arr, start, mid, end);
}