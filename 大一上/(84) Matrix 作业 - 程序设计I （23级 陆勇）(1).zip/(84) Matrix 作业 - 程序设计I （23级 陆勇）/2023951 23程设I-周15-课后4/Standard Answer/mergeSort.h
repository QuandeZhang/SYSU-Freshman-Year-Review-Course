#pragma once
#define MAX_SIZE 10001

void merge(int *arr, int start, int mid, int end);
void mergeSort(int *arr, int start, int end);