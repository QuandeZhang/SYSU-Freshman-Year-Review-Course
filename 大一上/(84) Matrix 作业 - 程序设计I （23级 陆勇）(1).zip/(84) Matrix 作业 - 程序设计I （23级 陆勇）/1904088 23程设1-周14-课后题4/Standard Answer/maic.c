#include <stdio.h>

int main()
{

    int n;
    scanf("%d", &n);
    int sum = (0 + n) * (n + 1) / 2;
    int x;
    for (int i = 0; i < n; i++)
    {

        scanf("%d", &x);
        sum -= x;
    }
    printf("%d", sum);
    return 0;
}
