#include <stdio.h>

int main(){
	int n, x;
	scanf("%d", &n);
	int nums[n + 1];
	for (int i = 0; i < n; i++){
		nums[i] = 1;
	}
	for (int i = 0; i < n; i++){
		scanf("%d", &x);
		if (x <= n && x >= 0) nums[x] = 0;
	}
	for (int i = 0; i <= n; i++){
		if (nums[i]) printf("%d ", i);
	}
	return 0;
}