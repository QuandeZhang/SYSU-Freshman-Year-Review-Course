# 23程设1-周14-课后题4

### Description

给定一个包含 `[0, n]` 中 `n` 个数的数组 `nums` ，找出 `[0, n]` 这个范围内没有出现在数组中的那个数。

### Input

第一行输入num数组长度

第二行输入数组

0 < 数组长度n<=1000
0<= nums[i]<=n

### Output

找出 `[0, n]` 这个范围内没有出现在数组中的那个数

### Sample Input1

```
5
0 1 3 4 5
```

### Sample Output1

```
2
```

### Sample Input2

```
2
0 1
```

### Sample Output1

```
2
```

