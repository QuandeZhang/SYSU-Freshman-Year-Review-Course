#include <stdio.h>
#include <math.h>

double calculateSequenceSum(int n){
	double ans = 7, a = 3, b = 4, x;
//	if (n == 1) return 3.0;
	for (int i = 3; i <= n; i++){
		x = hypot(a, b);
		ans += x;
		a = b;
		b = x;
	}
	return ans;
}

int main(){
	int n;
	scanf("%d", &n);
	printf("序列的和为%.3lf", calculateSequenceSum(n));
	return 0;
}