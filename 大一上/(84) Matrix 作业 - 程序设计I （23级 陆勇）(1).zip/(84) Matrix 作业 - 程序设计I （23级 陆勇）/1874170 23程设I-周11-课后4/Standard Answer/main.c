#include <stdio.h>
#include <math.h>

// 计算数学序列前N项的和
double calculateSequenceSum(int N) {
    double sum = 0;
    double x = 3; // 第一项
    double y = 4; // 第二项
    if(N==1){
        sum = x;
    }
    else if(N==0){
        sum = 0;
    }
    else{
        sum = x + y; // 前两项的和
    
    for (int i = 3; i <= N; ++i) {
        double temp = hypot(x,y); // 计算新的项
        sum += temp; // 加到总和中
        x = y; // 更新x为前一项的y
        y = temp; // 更新y为新的项
    }}
    
    return sum;
}

int main() {
    int N;
    
    // 输入N的值
    scanf("%d", &N);
    
    // 计算并输出前N项序列的和（结果保留3位小数）
    double sum = calculateSequenceSum(N);
    printf("序列的和为%.3lf",sum);
    
    return 0;
}
