#include <stdio.h>
#include <math.h>
int main()
{
	int n, x;
	scanf("%d", &n);
	x = n;
	while (n){
		n = x - ceil(x / 2);
		x = floor(x / 2);
		if (n == 0) break;
		printf("%d ", n);
	}
	return 0;
}