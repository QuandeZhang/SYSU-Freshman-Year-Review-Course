#include<stdio.h>
#include<math.h>
int main(){
    int n;
    scanf("%d", &n);
    while(n>0){
        printf("%d ", (int)ceil(n / 2.0));
        n = floor(n / 2.0);
    }
    return 0;
}