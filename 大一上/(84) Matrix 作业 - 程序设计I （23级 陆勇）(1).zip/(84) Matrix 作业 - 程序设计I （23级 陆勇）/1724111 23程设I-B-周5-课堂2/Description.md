# 23程设I-B-周5-课堂2

## 题目

有一个正方体与一个球体，分别输入正方体的边长和球的半径，输出它们的表面积。

## 问题输入

输入分两行，第一行是正方体的边长，第二行是球的半径，数值均在$[0, 1000]$范围内。

## 问题输出

输出分两行，第一行为"the surface area of the cube is "，然后是正方体的表面积，第二行为"the surface area of the sphere is "，然后是圆的表面积，要求输出的正方体表面积保留2位小数，球的表面积保留5位小数。

## 样例输入

```
3.2
2.6
```

## 样例输出

```
the surface area of the cube is 61.44
the surface area of the sphere is 84.90560
```

## 提示

$\pi$取3.14。
球的体积公式为：$4πr^{2}$

