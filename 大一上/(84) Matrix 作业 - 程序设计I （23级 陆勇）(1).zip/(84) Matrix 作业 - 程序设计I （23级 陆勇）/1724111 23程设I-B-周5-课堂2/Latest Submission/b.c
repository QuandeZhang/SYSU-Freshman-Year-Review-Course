#include <stdio.h>
#define PI 3.14

int main(){
	double cub, sph;
	scanf("%lf%lf", &cub, &sph);
	
	printf("the surface area of the cube is %.2lf\n", 6*cub*cub);
	printf("the surface area of the sphere is %.5lf", 4*PI*sph*sph);
	return 0;
}