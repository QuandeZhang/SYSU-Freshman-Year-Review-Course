#include<stdio.h>

int main() {
    double a, b;
    scanf("%lf%lf", &a, &b);
    printf("the surface area of the cube is %.2f\n", a * a * 6);
    printf("the surface area of the sphere is %.5f", 4 * b  * b * 3.14);
    return 0;
}