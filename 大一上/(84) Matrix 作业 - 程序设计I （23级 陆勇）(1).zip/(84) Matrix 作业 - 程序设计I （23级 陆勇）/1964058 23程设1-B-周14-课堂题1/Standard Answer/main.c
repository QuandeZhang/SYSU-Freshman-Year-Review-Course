#include <stdio.h>
#define MAX(a, b) ((a) > (b) ? (a) : (b))

int main()
{
    int n = 0;
    scanf("%d", &n);
    int nums[n];
    int i = 0;
    for (i = 0; i < n; ++i)
    {
        scanf("%d", &nums[i]);
    }

    int res = 0;
    int l = 0;
    while (l < n) {
        int cursum = nums[l++];
        while (l < n && nums[l] > nums[l - 1]) {
            cursum += nums[l++];
        }
        res = MAX(res, cursum);
    }
    printf("%d", res);
    return 0;

}
