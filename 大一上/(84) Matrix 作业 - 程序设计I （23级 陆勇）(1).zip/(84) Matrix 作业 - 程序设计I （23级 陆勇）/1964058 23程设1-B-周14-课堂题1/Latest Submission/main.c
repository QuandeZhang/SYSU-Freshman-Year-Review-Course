#include <stdio.h>

int main(){
	int n, max = 0, cur = 0, prev = -1;
	scanf("%d", &n);
	int nums[n];
	for (int i = 0; i < n; i++) scanf("%d", &nums[i]);
	for (int i = 0; i < n; i++){
		if (prev < nums[i]){
			cur += nums[i];
		} else cur = nums[i];
		max = max > cur ? max : cur;
		prev = nums[i];
	}
	printf("%d", max);
	return 0;
}