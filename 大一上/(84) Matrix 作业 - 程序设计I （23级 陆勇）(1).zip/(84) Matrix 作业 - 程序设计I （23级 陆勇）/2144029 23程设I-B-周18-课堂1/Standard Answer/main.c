#include <stdio.h>
#include "fun.h"


int main(void) {
	int n, num;
	scanf("%d", &n);

	struct Node* head = NULL;
	while (n--) {
		scanf("%d", &num);
		insert(&head, num);
	}
	print_linklist(head);
	delete_linklist(head);

}
