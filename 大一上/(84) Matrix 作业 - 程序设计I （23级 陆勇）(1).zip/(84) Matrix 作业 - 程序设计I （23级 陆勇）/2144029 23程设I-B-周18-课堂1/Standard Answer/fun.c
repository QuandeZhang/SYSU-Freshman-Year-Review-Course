#include "fun.h"

void insert(struct Node** head, int num) {
	struct Node* pre = NULL, *cur = *head;
	struct Node* t = (struct Node*) malloc(sizeof(struct Node));
	t->next = NULL;
	t->value = num;
	while (cur != NULL && num >= cur->value) {
		pre = cur;
		cur = cur->next;
	}
	if (pre == NULL) {
		t->next = *head;
		*head = t;
	}
	else {
		pre->next = t;
		t->next = cur;
	}
	pre = NULL;
	cur = NULL;
}

void print_linklist(struct Node* head) {
	struct Node* p = head;
	printf("%d", p->value);
	p = head->next;
	while (p != NULL) {
		printf(" %d", p->value);
		p = p->next;
	}
	printf("\n");
}

void delete_linklist(struct Node* head) {
	struct Node* p = NULL;
	while (head != NULL) {
		p = head;
		head = head->next;
		free(p);
	}
	p = NULL;
}