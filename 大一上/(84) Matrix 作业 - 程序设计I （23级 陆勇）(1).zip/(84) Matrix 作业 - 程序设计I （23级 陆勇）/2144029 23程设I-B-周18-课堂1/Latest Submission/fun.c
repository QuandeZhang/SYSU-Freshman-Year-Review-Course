#include "fun.h"
#include <stdlib.h>

void insert(struct Node** head, int num) {
    struct Node* dummyHead = (struct Node*)malloc(sizeof(struct Node));
    dummyHead->next = *head;
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->value = num;
    struct Node* tmp = dummyHead;
    while (tmp) {
        if (tmp->next == NULL || tmp->next->value >= num) {
            newNode->next = tmp->next;
            tmp->next = newNode;
            break;
        }
        tmp = tmp->next;
    }
    *head = dummyHead->next;
    free(dummyHead);
    dummyHead = NULL;
}

void print_linklist(struct Node* head) {
    struct Node* tmp = head;
    while (tmp) {
        printf("%d ", tmp->value);
        tmp = tmp->next;
    }
}

void delete_linklist(struct Node* head) {
    if (!head) return;
    struct Node* tmp = head->next;
    free(head);
    head = NULL;
    delete_linklist(tmp);
}

