# 23程设I-B-周18-课堂1

# Description

之前大家学习过结构体的简单应用了。现在要开始学习结构体的一些高级应用了——链表。

链表的定义依赖于下列结构体：
```cpp
struct Node {
	struct Node* next;
	int value;
};
```

链表是依靠一个一个节点连接而成：
```
 _ _    _ _    _ _
|v|n|->|v|n|->|v|n|->
```
其中`v`代表`value`,`n`存储着下一个节点的地址。

给出一串数字，大家要有序地插入到链表中。举个例子：`5 1 3 4` 在链表中的顺序为`1 3 4 5`。

函数的声明已经给出，请大家补全。
```cpp
void insert(struct Node** head, int num);

void print_linklist(struct Node* head);

void delete_linklist(struct Node* head);

```
其中`insert`是用来插入元素到链表中，`print_linklist`是从链表头输出到链表尾，`delete_linklist`是删除链表。

输入的第一行是数字个数 **$N$**。第二行是该串数字。输出链表的元素。**$1<=N<=1000$**

# Sample Input
```
4
5 1 3 4
```
# Sample Output
```
1 3 4 5
```