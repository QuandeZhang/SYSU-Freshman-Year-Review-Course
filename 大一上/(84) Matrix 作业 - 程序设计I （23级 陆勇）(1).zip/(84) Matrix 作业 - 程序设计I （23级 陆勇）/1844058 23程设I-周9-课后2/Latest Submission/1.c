#include <stdio.h>

int main(){
	int a, b, c, x, y, z;
	scanf("%d%d%d", &a, &b, &c);
	x = a < b ? a : b;
	x = x < c ? x : c;
	z = a > b ? a : b;
	z = z > c ? z : c;
	y = a + b + c - x - z;
	if (x + y <= z) printf("Not a triangle");
	else {
		if (x == y && x == z) printf("Equilateral");
		else if (x == y || y == z) printf("Isosceles");
		else printf("Scalene");
	}
	return 0;
}