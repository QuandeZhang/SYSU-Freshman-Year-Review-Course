#include <stdio.h>

int main(){
	printf("\"hello sysu\"");
	return 0;
} 