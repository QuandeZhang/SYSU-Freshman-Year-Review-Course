#include <stdio.h>


int main()
{

    printf("\"hello sysu\"\n");
    return 0;
}