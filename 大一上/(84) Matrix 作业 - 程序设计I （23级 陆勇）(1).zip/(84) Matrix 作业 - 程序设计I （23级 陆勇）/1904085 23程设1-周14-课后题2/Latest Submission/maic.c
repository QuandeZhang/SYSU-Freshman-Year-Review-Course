#include <stdio.h>

int main(){
	int len, count = 0;
	scanf("%d", &len);
	int coins[len];
	for (int i = 0; i < len; i++) scanf("%d", &coins[i]);
	
	for (int i = 0; i < len; i++){
		if (coins[i] % 2) count += coins[i] / 2 + 1;
		else count += coins[i] / 2;
	}
	printf("%d", count);
	return 0;
}