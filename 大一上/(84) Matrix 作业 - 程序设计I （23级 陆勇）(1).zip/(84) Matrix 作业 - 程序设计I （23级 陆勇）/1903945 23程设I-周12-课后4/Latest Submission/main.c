#include <stdio.h>

int main(){
	char a[110], b[110], c;
	int x[110], y[110], i = 0, j = 0, m = 0, n = 0;
	while ((c = getchar()) != ' ' && c != '\n' && c != EOF){
		a[m++] = c;
	}
	while ((c = getchar()) != '\n' && c != '\n' && c != EOF){
		b[n++] = c;
	}
	for (i = 0; i < 110; i++) x[i] = y[i] = 0;
	for (i = 0; i < m; i++){
		x[m-i-1] = a[i] - '0';
	}
	for (i = 0; i < n; i++){
		y[n-i-1] = b[i] - '0';
	}
	
//	for (i = 0; i < 110; i++){
//		printf("%d", x[i]);
//	}
//	puts("");
//	for (i = 0; i < 110; i++){
//		printf("%d", y[i]);
//	}
	
	for (i = 0; i < 109; i++){
		x[i] += y[i];
	}
	for (i = 0; i < 109; i++){
		if (x[i] > 9){
			x[i] -= 10;
			x[i+1]++;
		}
	}
	j = 109;
	while (j && !x[j]) j--;
	for (i = j; i >= 0; i--)
		printf("%d", x[i]);
	return 0;
} 