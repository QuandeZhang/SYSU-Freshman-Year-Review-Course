#include<stdio.h>
#include<string.h>

void Inverse(char *s)
 {
    int i;
    int length;
    char t;
    length=strlen(s);
    for(i=0;i<length-i-1;i++)
     {
        t=s[i];
        s[i]=s[length-i-1];
        s[length-i-1]=t;
     }
 }

 int Sum(char* a,char* b,char* sum)
 {
    int m=strlen(a);
    int n=strlen(b);
    int acc = 0;
    int t,i;
    Inverse(a);
    Inverse(b);
    for(i = 0;i < m || i < n;i++)
    {
        if(i >= m)             
            t = b[i] - '0' + acc;    
        else if(i >= n)          
            t = a[i] - '0'+ acc;    
         else                
            t = a[i] - '0'+ b[i] - '0' + acc;
        sum[i] = t % 10 + '0';
        if(t > 9)
            acc = 1;
        else
            acc = 0;
     }
    if(acc == 1)
        sum[i++] = '1';
    sum[i]='\0';
    Inverse(sum);
}
int main()
{
    char a[100],b[100],sum[250];
    scanf("%s%s",&a,&b);
    Sum(a,b,sum);
    printf("%s\n",sum);
    return 0;
}