#include <stdio.h>
#include <string.h>
#define LEN 210

int main(){
	char x[LEN], y[LEN] = "";
	char c, prev, l1, l2;
	int count = 0, i, j;
	scanf("%s", &x);
	l1 = strlen(x);
	prev = y[0] = x[0];
	count = j = 1;
	for (i = 1; i < l1; i++){
		if (x[i] == prev) count++;
		else {
			if (count < 10){
				y[j++] = count + '0';
			}
			else if (count < 100){
				y[j++] = count / 10 + '0';
				y[j++] = count % 10 + '0';
			}
			else {
				y[j++] = '1';
				y[j++] = '0';
				y[j++] = '0';
			}
			count = 1;
			y[j++] = prev = x[i];
		}
	}
	if (count > 1){
		if (count < 10){
				y[j++] = count + '0';
			}
			else if (count < 100){
				y[j++] = count / 10 + '0';
				y[j++] = count % 10 + '0';
			}
			else {
				y[j++] = '1';
				y[j++] = '0';
				y[j++] = '0';
			}
	}
	else if (count == 1){
		y[j++] = '1';
	}
	if (j < l1) printf("%s", y);
	else printf("%s", x);
	return 0;
}