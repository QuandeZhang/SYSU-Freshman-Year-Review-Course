#include <stdio.h>

int main(){
    int max, min, now;
    int point;
    int money;
    scanf("%d %d %d",&max,&min,&now);
    if(max>min){
        if(now<min){
            point = 3;
            money = 10;
        }
        else if(now>=min && now<=max){
            point = 0;
            money = 0;
        }
        else if(now>=max && now<=max*1.2){
            point = 3;
            money = (now-max)*10;
        }
        else if(now>max*1.2 && now<=max*1.5){
            point = 6;
            money = max*2 + (now*20-max*24);
        }
        else if(now>max*1.5){
            point = 12;
            money = (max)*8 + (now*50-max*75);
        }
    }
    else{
        point = -1;
        money = -1;
    }
    printf("%d %d",point,money);
}