#include <stdio.h>

int main(){
	int h, l, n, x = 0, money = 0;
	scanf("%d%d%d", &h, &l, &n);
	if (h <= l) {
		printf("-1 -1"); return 0;
	}
	if (n < l) {
		x = 3; money = 10;
	}
	else if (n > h){
		if (10 * n <= h * 12){
			x = 3;  money = (n - h) * 10;	
		}
		else if (10 * n <= h * 15){
			x = 6;  money = 2 * h + 20 * n - 24 * h;
		}
		else {
			x = 12;
			money = 2 * h + 6 * h + 50 * n - 75 * h; 
		}
	}
	
	printf("%d %d", x, money);
	return 0;
}