#include <stdio.h>

int main()
{
    printf("a+b\na-b\na*b\na/b\n");
    return 0;
}