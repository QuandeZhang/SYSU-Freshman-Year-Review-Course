#include <stdio.h>

int main(){
	printf("a+b\na-b\na*b\na/b");
	return 0;
} 