#include <stdlib.h>
#include "sort.h"

struct ListNode* mergeSort(struct ListNode* head) {
 if (head == NULL) {
        return head;
    }
    int length = 0;
    struct ListNode* node = head;
    while (node != NULL) {
        length++;
        node = node->next;
    }
    struct ListNode* dummyHead = malloc(sizeof(struct ListNode));
    dummyHead->next = head;
    for (int subLength = 1; subLength < length; subLength <<= 1) {
        struct ListNode *prev = dummyHead, *curr = dummyHead->next;
        while (curr != NULL) {
            struct ListNode* head1 = curr;
            for (int i = 1; i < subLength && curr->next != NULL; i++) {
                curr = curr->next;
            }
            struct ListNode* head2 = curr->next;
            curr->next = NULL;
            curr = head2;
            for (int i = 1; i < subLength && curr != NULL && curr->next != NULL;
                 i++) {
                curr = curr->next;
            }
            struct ListNode* next = NULL;
            if (curr != NULL) {
                next = curr->next;
                curr->next = NULL;
            }
            struct ListNode* merged = merge(head1, head2);
            prev->next = merged;
            while (prev->next != NULL) {
                prev = prev->next;
            }
            curr = next;
        }
    }
    head = dummyHead->next;
    free(dummyHead);
    dummyHead = NULL;
    return head;
}

struct ListNode* merge(struct ListNode* list1, struct ListNode* list2){
	struct ListNode* dummyHead = (struct ListNode*)malloc(sizeof(struct ListNode));
    struct ListNode *cur1 = list1;
    struct ListNode *cur2 = list2;
    struct ListNode *cur = dummyHead;
    while (cur1 && cur2) {
        if (cur1->val < cur2->val) {
            cur->next = cur1;
            cur1 = cur1->next;
        } else {
            cur->next = cur2;
            cur2 = cur2->next;
        }
        cur = cur->next;
    }
    if (cur1) cur->next = cur1;
    else cur->next = cur2;
    cur = dummyHead->next;
    free(dummyHead);
    dummyHead = NULL;
    return cur;
}