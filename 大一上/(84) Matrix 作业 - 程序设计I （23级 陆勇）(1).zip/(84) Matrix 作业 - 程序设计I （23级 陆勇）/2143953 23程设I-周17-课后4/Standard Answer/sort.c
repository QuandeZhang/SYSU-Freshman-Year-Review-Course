#include "sort.h"

struct ListNode* mergeSort(struct ListNode* head) {
	if (head == NULL || head->next == NULL) return head;
	
	struct ListNode* prev = NULL;
	struct ListNode* slow = head;
	struct ListNode* fast = head;
	
	while (fast != NULL && fast->next != NULL) {
		prev = slow;
		slow = slow->next;
		fast = fast->next->next;
	}
	
	prev->next = NULL;
	
	struct ListNode* list1 = mergeSort(head);
	struct ListNode* list2 = mergeSort(slow);
	
	return merge(list1, list2);
}

struct ListNode* merge(struct ListNode* list1, struct ListNode* list2) {
	struct ListNode* head = (struct ListNode*)malloc(sizeof(struct ListNode));
	head->next = NULL;
	
	struct ListNode* curr = head;
	while (list1 != NULL || list2 != NULL) {
		if (list1 == NULL) {
			curr->next = list2;
			curr = curr->next;
			list2 = list2->next;
		} else if (list2 == NULL) {
			curr->next = list1;
			curr = curr->next;
			list1 = list1->next;
		} else {
			int val1 = list1->val;
			int val2 = list2->val;
			if (val1 < val2) {
				curr->next = list1;
				curr = curr->next;
				list1 = list1->next;
			} else {
				curr->next = list2;
				curr = curr->next;
				list2 = list2->next;
			}
		}
	}
	curr->next = NULL;
	
	struct ListNode* res = head->next;
	free(head);
	return res;
}