#include <stdio.h>

int isReverse(unsigned int x) {
    for (int i = 0; i < 16; i++) {
        int a = 1 << i, b = 1 << (31 - i);
        int m = x & a, n = x & b;
        if ((m && n) || (!m && !n)) continue;
        else return 0;
    }
    return 1;
}
int main() {
    int n;
    scanf("%d", &n);
    while (n--) {
        unsigned int m, flag = 1;
        scanf("%u", &m);
        for (int i = 0; i < 32; i++) {
            unsigned int x = (m << i) | (m >> (32 - i));
            if (isReverse(x)) {
                flag = 0;
                break;
            }
        }
        if (flag) printf("false\n");
        else printf("true\n");
    }
}