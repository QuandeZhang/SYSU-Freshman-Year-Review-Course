int main(void){
    int a;
    scanf("%d", &a);
    a = (int) a / 100;
    printf("%d", a);
    return 0;
}