#include <stdio.h>

int main(){
	int i;
	scanf("%d", &i);
	i = i / 100;
	printf("%d", i);
	return 0;
}