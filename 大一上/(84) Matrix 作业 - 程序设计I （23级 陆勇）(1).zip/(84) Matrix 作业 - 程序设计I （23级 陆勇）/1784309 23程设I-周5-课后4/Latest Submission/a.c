#include <stdio.h>

int main(){
	int a, n = 5, ans = 0;
	scanf("%d", &a);
	while (n--){
		ans *= 10;
		ans += a % 10;
		a /= 10;
	}
	printf("%d", ans);
	return 0;
}