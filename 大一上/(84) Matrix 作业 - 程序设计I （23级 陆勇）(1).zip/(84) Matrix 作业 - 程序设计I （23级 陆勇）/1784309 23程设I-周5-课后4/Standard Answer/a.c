#include <stdio.h>

int main()
{
    int n;
    scanf("%d",&n);
    int a0,a1,a2,a3,a4;
    a0=n%10;
    a1=n/10%10;
    a2=n/100%10;
    a3=n/1000%10;
    a4=n/10000%10;
    printf("%d\n", a0*10000+a1*1000+a2*100+a3*10+a4);
    return 0;
}