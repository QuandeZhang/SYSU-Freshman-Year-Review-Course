#include <stdio.h>
#include <stdlib.h>

int main()
{

    int n;
    scanf("%d", &n);
    int *nums = (int*)malloc(sizeof(int)*n);
    //int nums[n];

    for (int i = 0; i < n; i++)
    {
        scanf("%d", &nums[i]);
    }
    int target;
    scanf("%d", &target);

    int l = 0, r = n - 1;
    while (l <= r)
    {
        int mid = (l + r) / 2;
        if (nums[mid] < target)
        {
            l = mid + 1;
        }
        else if (nums[mid] > target)
        {
            r = mid - 1;
        }
        else
        {
            printf("%d", mid);
            free(nums);
            return 0;
        }
    }
    printf("%d", -1);
    free(nums);
    return 0;
}
