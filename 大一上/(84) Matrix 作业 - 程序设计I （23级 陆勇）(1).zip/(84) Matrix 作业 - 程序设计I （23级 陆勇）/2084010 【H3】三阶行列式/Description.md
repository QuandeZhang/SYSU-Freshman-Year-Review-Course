# 【H3】三阶行列式

## 题目描述

输入一个三阶的矩阵，求出对应的行列式的值。

三阶行列式的定义如下：

$$
\begin{aligned}
\left| \begin{array}{ccc}
a_{11} \quad a_{12} \quad a_{13} \\
a_{21} \quad a_{22} \quad a_{23} \\
a_{31} \quad a_{32} \quad a_{33} \\
\end{array} \right|
=
& \quad a_{11}a_{22}a_{33} + a_{12}a_{23}a_{31} + a_{13}a_{21}a_{32} \\
& -a_{31}a_{22}a_{13} - a_{32}a_{23}a_{11} - a_{21}a_{12}a_{33}
\end{aligned}
$$

行列式中的每个元素为浮点数，使用**double**类型表示。

## 输入格式

输入为三行，每行包含3个数$a_i, b_i, c_i, i \in [1,3]$.

## 输出格式

行列式的值，保留四位小数。

## 样例输入

```
1 2 6
2 3 7
5 9 8
```

## 样例输出

```
The value of the determinant is 17.0000.
```

