# 【H6】丑数

# 丑数

## 定义

**丑数** 就是只包含质因数 `2`、`3` 和 `5` 的正整数。

给你一个整数 `n` ，请你判断 `n` 是否为 **丑数** 。如果是，返回 `true` ；否则，返回 `false` 。

## input

输入一个整数n（-100000<n<100000）

## output

输出true或者false（结果有换行）

## 例子

**示例 1：**

<pre><strong>输入：</strong>n = 6
<strong>输出：</strong>true
<strong>解释：</strong>6 = 2 × 3</pre>

**示例 2：**

<pre><strong>输入：</strong>n = 1
<strong>输出：</strong>true
<strong>解释：</strong>1 没有质因数，因此它的全部质因数是 {2, 3, 5} 的空集。习惯上将其视作第一个丑数。</pre>

**示例 3：**

<pre><strong>输入：</strong>n = 14
<strong>输出：</strong>false
<strong>解释：</strong>14 不是丑数，因为它包含了另外一个质因数 <code>7 </code>。</pre>

**示例 4：**

<pre><strong>输入：</strong>n = -1
<strong>输出：</strong>false
<strong>解释：</strong>-1不是丑数，因为它不是正整数。</pre>

