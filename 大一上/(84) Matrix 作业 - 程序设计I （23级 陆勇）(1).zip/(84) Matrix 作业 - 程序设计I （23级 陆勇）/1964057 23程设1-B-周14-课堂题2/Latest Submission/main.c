#include <stdio.h>
#include <string.h>

int main(){
	int n, j = -1;
	char s[105];
	scanf("%d\n", &n);
	// while (1){
	// 	scanf("%c", &s[++j]);
	// 	if (s[j] == '\n' || s[j] == EOF) break;
	// }
	scanf("%s", s);
    j = strlen(s);
	for (int i = 0; i < j; i++){
		if (s[i] - n < 'a') s[i] = s[i] - n + 26;
		else s[i] -= n;
	} 
	
	for (int i = 0; i < j; i++){
		printf("%c", s[i]);
	}
	return 0;
}