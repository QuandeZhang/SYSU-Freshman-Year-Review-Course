#include <stdio.h>
#include <string.h>
int main(void)
{
    int n = 0;
    scanf("%d", &n);
    char str[100];
    scanf("%s", str);
    int len = strlen(str);
    int i = 0;

    for (i = 0; i < len; ++i)
    {
        str[i] = 'a' + (26 + str[i] - 'a' - n) % 26;
    }
    for (i = 0; i < len; ++i)
    {
        printf("%c", str[i]);
    }
}
