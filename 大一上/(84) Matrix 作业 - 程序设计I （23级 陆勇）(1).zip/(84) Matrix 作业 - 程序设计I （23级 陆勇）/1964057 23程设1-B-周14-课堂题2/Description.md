# 23程设1-B-周14-课堂题2

# Description

给定一个字符串s1（只包含小写字母），再给定密钥 n 后将其加密为s2。
输出加密后字符串

- 加密规则：对于密钥n，将字符串中每一个字符替换为字母表顺序从右到左的第n位字母。
  注意'a' 前面是 'z'

例如：密钥n=1，  "bbcc" -> "aabb"  ,  'a' -> 'z'

# Input

输入的第一行为加密位n，
输入的第二行为字符串s1。
0 <= n <= 26
0 <= s1长度 <= 100

# Output

输入字符串s2

# Sample Input1

```
2
abc
```

# Sample Output1

```
yza
```

# Sample Input2

```
0
abc
```

# Sample Output2

```
abc
```

