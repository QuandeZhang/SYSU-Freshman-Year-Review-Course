#include <stdio.h>
int main(){
    int a,b,c;
    scanf("%d%d%d",&a,&b,&c);
    // 使用比较
    if(a<=b&&b<=c)
        printf("%d %d %d",a,b,c);
    else if(a<=c&&c<=b)
        printf("%d %d %d",a,c,b);
    else if(b<=a&&a<=c)
        printf("%d %d %d",b,a,c);
    else if(b<=c&&c<=a)
        printf("%d %d %d",b,c,a);
    else if(c<=a&&a<=b)
        printf("%d %d %d",c,a,b);
    else if(c<=b&&b<=a)
        printf("%d %d %d",c,b,a);
    // 使用交换
    // if (a > b) {
    //     int temp = a;
    //     a = b;
    //     b = temp;
    // }
    // if (a > c) {
    //     int temp = a;
    //     a = c;
    //     c = temp;
    // }
    // if (b > c) {
    //     int temp = b;
    //     b = c;
    //     c = temp;
    // }
    // printf("%d %d %d", a, b, c);
    return 0;
}