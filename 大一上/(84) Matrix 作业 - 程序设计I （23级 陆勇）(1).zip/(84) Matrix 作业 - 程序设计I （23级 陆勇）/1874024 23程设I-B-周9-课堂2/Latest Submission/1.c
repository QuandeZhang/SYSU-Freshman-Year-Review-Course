#include <stdio.h>
int main() {
    int a, b, c, x, y, z;
    scanf("%d%d%d", &a, &b, &c);
    x = a < b ? a : b;
    x = x < c ? x : c; 
    y = a > b ? a : b;
    y = y > c ? y : c;
    z = a + b + c - x - y;
    printf("%d %d %d", x, z, y);
    return 0;
}