#include <stdio.h>
#include <string.h>
#define L 10005
int main(){
    int n, max = 0, c = 0, count = 0, l1, l2, i, j;
    char s1[L], s2[L];
    
    scanf("%d", &n);
    while (n--){
        max = count = 0;
        scanf("%s%s", s1, s2);
        l1 = strlen(s1);
        l2 = strlen(s2);
        j = c = 0;
        for (i = 0; i < l1; i++){
            if (s1[i] == s2[j]){
                c++;
                j = (j + 1) % l2;
            }
            else {
                j = c = 0;
                if (s1[i] == s2[j]){
                c++;
                j = (j + 1) % l2;
                }
            }
            max = max > c ? max : c;
        }
        if (max >= l2) printf("%d\n", max);
        else printf("0\n");
    }
}