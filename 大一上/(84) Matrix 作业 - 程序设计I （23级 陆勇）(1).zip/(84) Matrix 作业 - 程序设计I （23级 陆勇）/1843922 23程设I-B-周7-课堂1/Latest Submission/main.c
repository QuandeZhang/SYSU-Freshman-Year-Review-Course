#include <stdio.h>

int main() {
	int h, l, n, x = 0;
	scanf("%d%d%d", &h, &l, &n);
	if (h <= l){
		printf("-1");
		return 0;
	}
	if (n < l) x = 3;
	else if (1.0 * n <= h * 1.2 && n > h) x = 3;
	else if (1.0 * n <= h * 1.5 && n > h) x = 6;
	else if (1.0 * n > h * 1.5) x = 12;
	else x = 0;
	printf("%d", x);
	return 0;
}