#include <stdio.h>

int main(){
    int max, min, now;
    int point;
    scanf("%d %d %d",&max,&min,&now);
    if(max>min){
        if(now<min){
            point = 3;
        }
        else if(now>=min && now<=max){
            point = 0;
        }
        else if(now>=max && now<=max*1.2){
            point = 3;
        }
        else if(now>max*1.2 && now<=max*1.5){
            point = 6;
        }
        else if(now>max*1.5){
            point = 12;
        }
    }
    else{
        point = -1;
    }
    printf("%d",point);
}