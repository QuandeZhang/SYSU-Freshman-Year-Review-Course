# 23程设I-周4-课后3

## 题目

输出年月日，格式参考输出样例
本题带随机输入，请不要直接输出字符串

## 输入样例

2023 9 22

## 输出样例

```
year: 2023
month: 9
day: 22
```

## 代码提示

```
#include <stdio.h>

int main() {
    int year, month, day;
    scanf("%d%d%d",&year, &month, &day);
    // 在这里填写你的代码
    
    return 0;
}
```

`printf("%d",a)`表示输出一个整形变量

