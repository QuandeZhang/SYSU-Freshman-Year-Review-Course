#include <stdio.h>

int main(){
	int y, m, d;
	scanf("%d %d %d", &y, &m, &d);
	printf("year: %d\n", y);
	printf("month: %d\n", m);
	printf("day: %d", d);
	return 0;
} 