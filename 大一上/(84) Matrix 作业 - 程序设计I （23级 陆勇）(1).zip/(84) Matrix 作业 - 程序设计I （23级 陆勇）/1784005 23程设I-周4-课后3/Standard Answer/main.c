#include <stdio.h>

int main() {
    int year, month, day;
    scanf("%d%d%d",&year, &month, &day);
    // 在这里填写你的代码
    printf("year: %d\nmonth: %d\nday: %d",year,month,day);
    return 0;
}