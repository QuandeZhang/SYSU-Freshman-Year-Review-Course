#include <stdio.h>
#include "matrixAddT.h"

int main()
{
	int mat[ROW][COL];

	// printf("Enter elements in first matrix of size %dx%d\n", ROW, COL);
	matrixInput(mat);

	// call function to add mat with mat.T
	matrixAddT(&mat[0][0]);

	int *p[ROW] = {NULL, NULL, NULL};
	for (int row = 0; row < ROW; row++)
		*(p + row) = *(mat + row);

	// print result
	matrixPrint(p);

	return 0;
}

