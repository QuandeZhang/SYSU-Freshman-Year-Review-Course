#pragma once
#define ROW 3
#define COL 3

void matrixInput(int (*mat)[COL]);
void matrixPrint(int *mat[ROW]);
void matrixAddT(int *mat);

