#include <stdio.h>
#include "matrixAddT.h"

void matrixInput(int (*mat)[COL])
{
	int row, col;
	for (row = 0; row < ROW; row++)
	{
		for (col = 0; col < COL; col++)
		{
			scanf("%d", *(mat + row) + col);
		}
	}
}


void matrixPrint(int *mat[ROW])
{
	int row, col;
	for (row = 0; row < ROW; row++)
	{
		for (col = 0; col < COL; col++)
		{
			printf("%d ", *(*(mat + row) + col));
		}
		printf("\n");
	}
}


void matrixAddT(int *mat)
{
	int row, col;
    for (row = 0; row < ROW; row++)
    {
        for (col = row; col < COL; col++)
        {
            int tmp = *(mat + row * ROW + col) + *(mat + col * COL + row);
            *(mat + row * ROW + col) = tmp;
            *(mat + col * COL + row) = tmp;             
        }
    }
}