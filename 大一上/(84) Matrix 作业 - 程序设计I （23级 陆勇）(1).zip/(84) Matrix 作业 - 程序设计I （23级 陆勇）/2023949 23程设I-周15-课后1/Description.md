# 23程设I-周15-课后1

# 题目描述

根据主函数和头文件提示，编写子函数

```
void matrixInput(int (*mat)[COL]);
void matrixPrint(int *mat[ROW]);
void matrixAddT(int *mat);
```

分别实现矩阵的**输入**，**输出**，**与自身的转置相加**：

1. `void matrixInput(int (*mat)[COL]);`： 输入`int`类型的矩阵元素，用方阵`mat`存储；
2. `void matrixPrint(int *mat[ROW]);` ：输出方阵`mat`中的各个元素；
3. `void matrixAddT(int *mat);` ：计算方阵`mat`与自身转置的和，结果存储在`mat`中。

**Hint**：请注意三个子函数的传入参数类型**各不相同**。

# 输入格式

输入一个**三行三列**的方阵 $A$，每个元素均为 `int` 类型。

# 输出格式

输出一个**三行三列**的方阵 $B$，每个元素均为 `int` 类型，$B=A+A^T$。

# 输入样例1

```
1 2 3
4 5 6
7 8 9
```

# 输出样例1

```
2 6 10 
6 10 14 
10 14 18 
```

# 输入样例2

```
0 1 0
1 0 0
0 0 -1
```

# 输出样例2

```
0 2 0 
2 0 0 
0 0 -2 
```

