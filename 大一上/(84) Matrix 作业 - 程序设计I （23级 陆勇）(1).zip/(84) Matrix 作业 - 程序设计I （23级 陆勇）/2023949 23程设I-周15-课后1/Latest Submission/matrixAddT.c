// 课后1 
#include <stdio.h>
#define ROW 3
#define COL 3
void matrixInput(int (*mat)[COL]) {
    for (int i = 0; i < COL; i++) {
        for (int j = 0; j < COL; j++) {
            scanf("%d", &mat[i][j]);
        }
    }
}

void matrixPrint(int *mat[ROW]){
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            printf("%d ", mat[i][j]);
        }
        printf("\n");
    }
}

void matrixAddT(int *mat) {
    for (int i = 0; i < 3; i++) {
        for (int j = i; j < 3; j++) {
            (mat + 3 * i)[j] = (mat + 3 * j)[i] = (mat + 3 * j)[i] + (mat + 3 * i)[j];
        }
    }
}