#include <stdio.h>

int main(){
	int a, b, sum = 0, n = 2;
	while (n--){
		scanf("%d %d", &a, &b);
		sum += a*b;
	}
	printf("%d", sum);
	return 0;
}