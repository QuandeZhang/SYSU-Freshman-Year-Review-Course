#include <stdio.h>

int main() {
    double x, y;
    scanf("%lf%lf", &x, &y);
    double a = x + y, b = x * y;
    if (a > b) printf("%.2lf %.2lf", a, b);
    else printf("%.2lf %.2lf", b, a);
    return 0;
}