#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ListNode.h"

struct ListNode* addNode(int val) {
    struct ListNode* p = (struct ListNode*)malloc(sizeof(struct ListNode));
    p->val = val;
    p->next = NULL;
    return p;
}

void freeList(struct ListNode* head) {
    if (head == NULL)   return;
    freeList(head->next);
    head->next = NULL;
    free(head);
}

void printList(struct ListNode* head) {
    if (head == NULL) {
        puts("NULL");
        return;
    }
    while (head) {
        printf("%d ", head->val);
        head = head->next;
    }
    puts("");
}

int main() {
    int n, value;
    scanf("%d %d", &n, &value);
    
    struct ListNode* head = addNode(-1), *cur = head;
    for (int i = 1, x; i <= n; ++i) {
        scanf("%d", &x);
        cur->next = addNode(x);
        cur = cur->next;
    }

    struct ListNode* res = deleteNodeOfList(head->next, value);
    printList(res);
    freeList(res);
    free(head);
    return 0;
}
