#include "ListNode.h"

struct ListNode* deleteNodeOfList(struct ListNode* list, int value) {
    if (list == NULL)   return list;
    struct ListNode* head = list, *pre = list;
    if (head->val == value) {
        head = head->next;
        free(pre);
        return head;
    }

    struct ListNode* cur = pre->next;
    while (cur) {
        if (cur->val == value) {
            pre->next = cur->next;
            free(cur);
            break;
        }
        pre = cur;
        cur = cur->next;
    }
    return head;
}