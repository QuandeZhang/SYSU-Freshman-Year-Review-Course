#pragma once

#include <stdlib.h>

struct ListNode {
    int val;
    struct ListNode* next;
};

struct ListNode* deleteNodeOfList(struct ListNode* list, int value);