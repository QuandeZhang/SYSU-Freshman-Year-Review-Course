#include <stdlib.h>
#include <stdio.h>
#include "ListNode.h"

struct ListNode* deleteNodeOfList(struct ListNode* list, int value) {
    struct ListNode* dummyHead = (struct ListNode*)malloc(sizeof(struct ListNode));
    dummyHead->next = list;
    struct ListNode* cur = dummyHead;
    while (cur->next) {
        if (cur->next->val == value) {
            struct ListNode* tmp = cur->next;
            cur->next = tmp->next;
            free(tmp);
            tmp = NULL;
        } else cur = cur->next;
    }
    struct ListNode* ans = dummyHead->next;
    free(dummyHead);
    dummyHead = NULL;
    return ans;
}