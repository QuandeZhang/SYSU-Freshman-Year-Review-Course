#include <stdio.h>

// 判断输入的四位数是否符合密码规则
int crackPassword(int num) {
    int first, second, third, fourth;
    
    // 提取四位数的每一位数字
    first = num / 1000;
    second = (num % 1000) / 100;
    third = (num % 100) / 10;
    fourth = num % 10;
    
    // 判断密码规则
    if ((first == fourth - 1 || first == fourth + 1) && second == fourth * 2 && third == first + fourth) {
        return 1; // 符合密码规则
    } else {
        return 0; // 不符合密码规则
    }
}

int main() {
    int num;
    
    // 输入四位数
    scanf("%d", &num);
    
    // 调用函数判断是否符合密码规则并输出结果
    if (crackPassword(num)) {
        printf("密码破解成功。");
    } else {
        printf("密码破解失败。");
    }
    
    return 0;
}
