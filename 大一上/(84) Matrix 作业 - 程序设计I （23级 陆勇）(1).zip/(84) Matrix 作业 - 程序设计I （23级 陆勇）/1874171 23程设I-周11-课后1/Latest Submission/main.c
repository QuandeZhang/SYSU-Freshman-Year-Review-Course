#include <stdio.h>
#include <math.h>
int main(){
	int a, b, c, d;
	scanf("%1d%1d%1d%1d", &a, &b, &c, &d);
	if ((a - d == 1 || a - d == -1) && (b == 2 * d && c == a + d)){
		printf("密码破解成功。"); 
	}
	else printf("密码破解失败。");
	return 0; 
} 