#pragma once
void rotate(int**matrix,int n);