# 23程设1-B-周13-课堂1

# Description

给定一个长度小于100的字符串，里面可能包含数字、字母、符号等。

现需要你把里面的数字按序输出，并以空格分割。

# Sample Input

78y7

# Sample Output

7 8 7

# Sample Input

aaaa

# Sample Output

