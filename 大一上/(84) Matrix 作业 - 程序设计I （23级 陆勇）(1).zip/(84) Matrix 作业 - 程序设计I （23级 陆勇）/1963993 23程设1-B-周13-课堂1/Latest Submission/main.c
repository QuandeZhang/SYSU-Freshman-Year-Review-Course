#include <stdio.h>

int main(){
    char c[105];
    scanf("%s", c);
    for (int i = 0; i < strlen(c); i++){
        if (c[i] <= '9' && c[i] >= '0'){
            printf("%c ", c[i]);
        }
    }
    return 0;
}