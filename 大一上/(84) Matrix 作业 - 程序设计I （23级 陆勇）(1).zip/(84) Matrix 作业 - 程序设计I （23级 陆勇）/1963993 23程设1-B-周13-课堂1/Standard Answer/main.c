#include <stdio.h>
#include <string.h>
#include <stdbool.h>
int main(){
	char str[100];
	scanf("%s",str);
	char arr[100],j=0;
	bool havenumber = false;
	for(int i=0;i<strlen(str);i++){
		if(str[i]>='0'&&str[i]<='9'){
			arr[j]=str[i];
			j++;
			havenumber = true;
		}	
	}
	if(havenumber){
		for(int i=0;i<j-1;i++)
			printf("%c ",arr[i]);
		printf("%c",arr[j-1]);
	}
	return 0;
}