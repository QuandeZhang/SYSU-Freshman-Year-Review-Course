# 23程设I-周17-课后3

# 题目描述

用链表实现一个栈及相关函数，需要实现的函数如下：

+ `struct Stack* initStack();`初始化一个栈，返回其指针。
+ `int top(struct Stack* stack);`获取栈顶元素，若栈为空，返回`-1`。
+ `void push(struct Stack* stack, int val);`插入一个元素。
+ `int pop(struct Stack* stack);`删除一个元素，返回元素值，若栈为空，返回`-1`。
+ `int empty(struct Stack* stack);`检查栈是否为空，若为空返回`1`，若不空返回`0`。
+ `void freeStack(struct Stack* stack);`释放栈的内存。

保证栈中每一个元素`val`都大于等于`0`。

# 输入描述

第一行输入正整数`n`，代表程序需要执行的操作数。
接下来`n`行，每行包含字符串`s`(操作种类)及操作需要的参数。

`1 <= n <= 1000`

# 样例输入

```c
15
top
empty
push 2
push 3
top
empty
pop
push 6
push 7
pop
pop
pop
pop
push 9
top
```

# 样例输出

```c
top: fail
stack empty: true
push: 2
push: 3
top: 3
stack empty: false
pop: 3
push: 6
push: 7
pop: 7
pop: 6
pop: 2
pop: fail
push: 9
top: 9

```

# 提示

栈 -- 先进后出

