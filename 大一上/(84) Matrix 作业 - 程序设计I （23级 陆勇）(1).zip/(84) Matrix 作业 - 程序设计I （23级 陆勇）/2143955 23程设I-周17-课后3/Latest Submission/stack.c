#include "stack.h"
#include <stdlib.h>

struct Stack* initStack() {
    struct Stack* newHead = (struct Stack*)malloc(sizeof(struct Stack));
    newHead->head = NULL;
    return newHead;
}


int top(struct Stack* stack) {
    if (empty(stack)) return -1;
    return stack->head->val;
}

void push(struct Stack* stack, int val) {
    struct ListNode* newNode = (struct ListNode*)malloc(sizeof(struct ListNode));
    newNode->val = val;
    newNode->next = stack->head;
    stack->head = newNode;
}

int pop(struct Stack* stack) {
    if (empty(stack)) return -1;
    struct ListNode* tmp = stack->head;
    stack->head = tmp->next;
    int ans = tmp->val;
    free(tmp);
    tmp = NULL;
    return ans;
}

int empty(struct Stack* stack) {
    if (stack->head == NULL) return 1;
    return 0;
}

void freeStack(struct Stack* stack) {
    while (!empty(stack)) pop(stack);
    free(stack);
    stack = NULL;
}

