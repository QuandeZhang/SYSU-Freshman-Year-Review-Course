#include "stack.h"

struct Stack* initStack() {
	struct Stack* stack = (struct Stack*)malloc(sizeof(struct Stack));
	struct ListNode* head = (struct ListNode*)malloc(sizeof(struct ListNode));
	head->next = NULL;
	stack->head = head;
	return stack;
}

int top(struct Stack* stack) {
	if (empty(stack)) return -1;
	struct ListNode* head = stack->head;
	return head->next->val;
}

void push(struct Stack* stack, int val) {
	struct ListNode* head = stack->head;
	struct ListNode* newNode = (struct ListNode*)malloc(sizeof(struct ListNode));
	newNode->val = val;
	newNode->next = head->next;
	head->next = newNode;
}

int pop(struct Stack* stack) {
	if (empty(stack)) return -1;
	struct ListNode* head = stack->head;
	struct ListNode* curr = head->next;
	int res = curr->val;
	head->next = curr->next;
	free(curr);
	return res;
}

int empty(struct Stack* stack) {
	struct ListNode* head = stack->head;
	return head->next == NULL;
}

void freeStack(struct Stack* stack) {
	struct ListNode* head = stack->head;
	while (head != NULL) {
		struct ListNode* curr = head;
		head = head->next;
		free(curr);
	}
	free(stack);
}