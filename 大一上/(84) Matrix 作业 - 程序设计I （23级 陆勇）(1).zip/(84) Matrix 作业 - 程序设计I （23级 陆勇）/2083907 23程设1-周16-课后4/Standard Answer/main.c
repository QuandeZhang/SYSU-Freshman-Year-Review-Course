#include <stdio.h>

int findCoinPosition(int n,int m);

int main() {
    int n, m;

    // 输入放入硬币的纸杯编号
    //printf("请输入放入硬币的纸杯编号：");
    scanf("%d", &n);

    // 输入要判断的纸杯编号
    //printf("请输入要判断的纸杯编号：");
    scanf("%d", &m);

    // 调用函数判断硬币位置
    int coinPosition = findCoinPosition(n,m);

    // 输出结果
    if (coinPosition == m) {
        printf("Yes!\n");
    } else {
        printf("No!\n");
    }

    return 0;
}

int findCoinPosition(int n, int m) {
	n =(n%3==0)? n+3:n;
	n =(n%2==0)? n+2:n;
	n=n>100? n-100:n;
	return n;
}