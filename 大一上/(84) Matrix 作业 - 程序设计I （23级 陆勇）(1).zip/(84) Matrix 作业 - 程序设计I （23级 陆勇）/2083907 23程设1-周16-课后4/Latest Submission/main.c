#include <stdio.h>

int main() {
    int n, m;
    scanf("%d%d", &n, &m);
    if (n % 3 == 0) n = (n + 3) % 100;
    if (n == 0) n = 100;
    if (n % 2 == 0) n = (n + 2) % 100;
    if (n == 0) n == 100;
    if (n == m) printf("Yes!");
    else printf("No!");
    return 0;
}