#include <stdio.h>
#define sqrt2 1.414
#define sqrt3 1.732

int main(){
	double r;
	scanf("%lf", &r);
	
	printf("the surface area of the regular tetrahedron is %.3f", sqrt3*r*r);
	puts("");
	printf("the volume of the regular tetrahedron is %.3f", sqrt2*r*r*r/12);
	return 0;
}