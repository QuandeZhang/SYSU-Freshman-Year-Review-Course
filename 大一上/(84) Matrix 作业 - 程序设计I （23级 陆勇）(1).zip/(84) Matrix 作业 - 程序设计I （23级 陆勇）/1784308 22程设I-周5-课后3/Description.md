# 22程设I-周5-课后3

## 题目

​正四面体是由四个全等的等边三角形围成的空间封闭图形，输入等边三角形的边长，输出正四面体的表面积和体积。

## 问题输入

等边三角形的边长，数值在$[0, 100]$范围内。

## 问题输出

输出分两行，第一行为"the surface area of the regular tetrahedron is "，然后是正四面体的表面积，第二行为"the volume of the regular tetrahedron is "，然后是正四面体的体积，全部保留3位小数。

## 样例输入

```
3.2
```

## 样例输出

```
the surface area of the regular tetrahedron is 17.736
the volume of the regular tetrahedron is 3.861
```

## 提示

正四面体的表面积公式为：$(√3)a^2$

正四面体的体积公式为：$(√2)a^3/12$

$√2$取***1.414***
$√3$取***1.732***

