#include<stdio.h>

int main() {
    double a, b;
    scanf("%lf", &a);
    printf("the surface area of the regular tetrahedron is %.3f\n", 1.732* a * a);
    printf("the volume of the regular tetrahedron is %.3f", 1.414 * a * a * a /12);
    return 0;
}