#include <stdio.h>

int main()
{
    int a;
    int b;
    scanf("%d %d",&a,&b);
    // 交换
    a = a ^ b;
    b = a ^ b;
    a = a ^ b;

    printf("a = %d, b = %d\n", a, b);
    return 0;
}