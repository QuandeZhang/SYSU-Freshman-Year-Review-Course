#include <stdio.h>

int main(){
    int rank;
    int result1 = 1;
    int result2 = 2;

    scanf("%d",&rank);
    for(int i = 3; i <= rank ; i ++){
        int tmp = result2 + result1;
        result1 = result2;
        result2 = tmp;
    }
    printf("%d",result2);
    return 0;
}