#include <stdio.h>

int main()
{
	int n, i, a = 1, b = 1, ans;
	scanf("%d", &n);
	for (i = 2; i <= n; i++){
		ans = a + b;
		a = b;
		b = ans;
	}
	printf("%d", ans);
	return 0;
}