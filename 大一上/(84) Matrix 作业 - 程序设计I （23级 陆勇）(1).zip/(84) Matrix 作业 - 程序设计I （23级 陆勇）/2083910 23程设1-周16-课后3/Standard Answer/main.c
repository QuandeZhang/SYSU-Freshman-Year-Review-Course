#include <stdio.h>

int isSubArray(int a[], int sizeA, int b[], int sizeB, int *startIndex);

int main() {
    int sizeA, sizeB;

    // 获取数组 A 的大小
    //printf("请输入数组 A 的大小：");
    scanf("%d", &sizeA);

    int A[sizeA];
    //printf("请输入数组 A：\n");
    for (int i = 0; i < sizeA; i++) {
        scanf("%d", &A[i]);
    }

    // 获取数组 B 的大小
    //printf("请输入数组 B 的大小：");
    scanf("%d", &sizeB);

    int B[sizeB];
    //printf("请输入数组 B：\n");
    for (int i = 0; i < sizeB; i++) {
        scanf("%d", &B[i]);
    }

    int startIndex;

    // 调用函数判断 B 是否是 A 的子数组
    if (isSubArray(A, sizeA, B, sizeB, &startIndex)) {
        printf("Yes,%d\n", startIndex);
    } else {
        printf("No\n");
    }

    return 0;
}

int isSubArray(int a[], int sizeA, int b[], int sizeB, int *startIndex) {
    for (int i = 0; i <= sizeA - sizeB; i++) {
        int j;

        // 检查数组 B 是否是数组 A 中以 i 为起始位置的子数组
        for (j = 0; j < sizeB; j++) {
            if (a[i + j] != b[j]) {
                break;
            }
        }

        // 如果 j 等于 sizeB，说明数组 B 是数组 A 中的子数组
        if (j == sizeB) {
            *startIndex = i;
            return 1; // 返回1表示是子数组
        }
    }

    return 0; // 返回0表示不是子数组
}
