#include <stdio.h>

int main() {
    int la, lb;
    char a[500], b[500];
    scanf("%d\n", &la);
    gets(a);
    scanf("%d\n", &lb);
    gets(b);
    char* idx = strstr(a, b);
    if (idx == NULL) printf("No");
    else {
        printf("Yes,%d", (idx-a)/2);
    }
    return 0;
}