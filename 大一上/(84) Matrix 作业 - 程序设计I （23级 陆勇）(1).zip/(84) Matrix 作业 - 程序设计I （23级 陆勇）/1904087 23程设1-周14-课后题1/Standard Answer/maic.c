#include <stdio.h>
#include <stdlib.h>

char str[1000];
int targets[1000];
int len = 0;

int main() {
    int n;
    char tar;

    scanf("%d", &n);
    if(n == 0){
        printf("%d", 0);
        return 0;
    }
    scanf("%s", str);
    scanf(" %c", &tar);

    
    for (int i = 0; i < n; i ++) {
        if (str[i] == tar) {
            targets[len] = i;
            len ++;
        }
    }

    for (int i = 0; i < n; i ++) {
        int tmp = 9999, idx;
        for (int j = 0; j < len; j ++) {
            idx = abs(targets[j] - i);
            if (tmp > idx) {
                tmp = idx;
            }
        }
        printf("%d ", tmp);
    }

    return 0;
}