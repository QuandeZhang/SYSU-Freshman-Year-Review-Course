#include <stdio.h>
#include <math.h>
int main(){
	int n, j = 0;
	scanf("%d\n", &n);
    if (!n) {
        printf("0");
    }
	char str[n];
	char c;
	int idx[n];
	for (int i = 0; i < n; i++){
		scanf("%c", &str[i]);
	}
	scanf("\n%c", &c);
	for (int i = 0; i < n; i++){
		if (str[i] == c) idx[j++] = i;
	}
	int mind = n;
	for (int i = 0; i < n; i++){
		mind = n;
		for (int k = 0; k < j; k++){
			mind = mind < (abs(i - idx[k])) ? mind : (abs(i - idx[k]));
			if (mind < 0) mind = 0;
		}
		printf("%d ", mind);
	}
	return 0;
}