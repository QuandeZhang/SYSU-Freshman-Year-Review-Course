# 23程设I-周7-课后1

## 题目

请实现一个函数allOddBits。它会返回1，当且仅当输入的二进制数字所有奇数位被设为了1。位的编号是从0到31编号的，其中，0代表最低位（least significant）31代表最高位（most significant）例如：allOddBits(0xFFFFFFFD) = 0, allOddBits(0xAAAAAAAA) = 1。输入样例为0xAAAAAAAA

bonus:
这道题可以不用使用for循环和if判断只使用位运算和逻辑运算完成

## 问题输入

**一个数a，范围为int**

## 问题输出

**0或1**

## 输入样例

```
-1431655766
```

## 输出样例

```
1
```

<pre class="md-fences md-end-block ty-contain-cm modeLoaded md-focus" spellcheck="false" lang="c++" cid="n65" mdtype="fences"><div class="CodeMirror cm-s-inner cm-s-null-scroll CodeMirror-wrap" lang="c++"><br class="Apple-interchange-newline"/></div></pre>

