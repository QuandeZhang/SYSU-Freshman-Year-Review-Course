#include <stdio.h>

int allOddBits(int a){
	int b = 0XAAAAAAAA;
	int c = a & b;
	if (c == b) return 1;
	else return 0;
}

int main()
{
	int a;
	scanf("%d", &a);
	printf("%d", allOddBits(a));
	return 0;
	
}