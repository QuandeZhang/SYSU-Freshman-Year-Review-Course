#include <stdio.h>

//problem from cmu csapp datalab
int allOddBits(int x) {
  int mask = 0xaa;
  mask = mask << 8 | mask;
  mask = mask << 8 | mask;
  mask = mask << 8 | mask;
  return !((x & mask) ^ mask);
}

int main() {
    int a;
    scanf("%d", &a);
    printf("%d", allOddBits(a));
}