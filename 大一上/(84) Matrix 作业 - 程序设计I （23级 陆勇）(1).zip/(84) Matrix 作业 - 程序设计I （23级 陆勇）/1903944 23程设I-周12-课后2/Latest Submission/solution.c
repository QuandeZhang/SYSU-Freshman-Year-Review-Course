void spiralOrder(int **matrix, int m, int n){
    int i, j, x = 0, y = 0, op = 1, count = 0;
    int visit[m][n];
    for (i = 0; i < m; i++){
        for (j = 0; j < n; j++)
            visit[i][j] = 0;
    }
    while (1){
        if (!visit[x][y]){
            printf("%d ", matrix[x][y]);
            count++;
            visit[x][y] = 1;
            if (count == m * n) break;
        }
        
        if (op == 1){
            if (y + 1 == n || visit[x][y+1]){
                op = 2;
            }
            else y++;
        }
        if (op == 2){
            if (x + 1 == m || visit[x+1][y]){
                op = 3;
            }
            else x++;
        }
        if (op == 3){
            if (y == 0 || visit[x][y-1]){
                op = 4;
            }
            else y--;
        }
        if (op == 4){
            if (x == 0 || visit[x-1][y]){
                op = 1;
            }
            else x--;
        }
        
    }
}