#include <stdio.h>
#include <math.h>

// 计算整数的平方根
double calculateSquareRoot(int num) {
    return sqrt(num);
}

// 计算整数的立方根
double calculateCubeRoot(int num) {
    return cbrt(num);
}

int main() {
    int num;
    
    // 输入一个整数
    scanf("%d", &num);
    
    // 计算并输出平方根和立方根
    printf("平方根为%.2lf\n", calculateSquareRoot(num));
    printf("立方根为%.2lf", calculateCubeRoot(num));
    
    return 0;
}
