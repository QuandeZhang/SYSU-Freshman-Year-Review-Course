#include <stdio.h>
#include <math.h>
int main(){
	int n;
	double a, b;
	scanf("%d",&n);
	a = pow(n, 1.0/2);
	b = pow(n, 1.0/3);
	printf("平方根为%.2lf\n立方根为%.2lf", a, b); 
} 