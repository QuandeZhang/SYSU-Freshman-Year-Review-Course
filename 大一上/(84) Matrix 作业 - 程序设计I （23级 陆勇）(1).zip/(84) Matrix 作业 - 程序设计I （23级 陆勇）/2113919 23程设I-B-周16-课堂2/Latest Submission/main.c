#include <stdio.h>

int main() {
    int n, d = -1, count = 0, i = 0;
    scanf("%d", &n);
    int a[n];
    for (int k = 0; k < n; k++) a[k] = 0;
    while (count < n - 1) {
        if (!a[i]) d = (d + 1) % 3;
        if (d == 2 && !a[i]) {
            a[i] = 1;
            count++;
        }
        i = (i + 1) % n;
    }
    int x;
    for (x = 0; x < n; x++) {
        if (!a[x]) break;
    }
    printf("%d", x+1);
    return 0;
}