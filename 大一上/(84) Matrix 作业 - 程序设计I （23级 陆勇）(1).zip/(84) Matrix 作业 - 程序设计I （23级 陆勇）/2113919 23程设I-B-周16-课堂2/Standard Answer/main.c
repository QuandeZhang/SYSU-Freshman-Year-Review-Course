#include <stdio.h>

#define MAX_STUDENTS 100

int findLastStudent(int n);

int main() {
    int n;

    // 获取学生总数
    scanf("%d", &n);

    // 找出最后留下的学生编号
    int lastStudent = findLastStudent(n);

    printf("%d\n", lastStudent);

    return 0;
}

int findLastStudent(int n) {
    // 创建数组表示学生是否已经退出
    int students[MAX_STUDENTS];
    for (int i = 0; i < n; i++) {
        students[i] = 1;  // 初始化为未退出
    }

    int count = 0;  // 记录报数次数
    int index = 0;  // 数到3的学生索引

    while (1) {
        // 数到3的学生退出
        if (students[index] == 1) {
            count++;
            if (count == 3) {
                students[index] = 0;  // 标记为已退出
                count = 0;  // 重新开始报数
            }
        }

        // 移动到下一个学生
        index++;

        // 判断是否回到队伍开头
        if (index == n) {
            index = 0;
        }

        // 检查是否只剩下一个学生
        int remainingStudents = 0;
        int lastStudent = 0;
        for (int i = 0; i < n; i++) {
            if (students[i] == 1) {
                remainingStudents++;
                lastStudent = i + 1;  // 记录最后一个学生的编号
            }
        }

        if (remainingStudents == 1) {
            return lastStudent;
        }
    }
}
