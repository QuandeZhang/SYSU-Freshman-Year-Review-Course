#include <stdio.h>
#include <math.h>
#define pi 3.14

int main(){
	float v;
	scanf("%f", &v);
	double r, s;
	r = v * 3 / 4 / pi;
	r = pow(r, 1.0 / 3);
	s = 4 * pi * r * r;
	printf("%.2f", s);
	return 0;
}