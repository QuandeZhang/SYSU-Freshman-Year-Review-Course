#include<stdio.h>
#include<math.h>
int main()
{
    double a;
    scanf("%lf",&a);
    a = ((a*3)/4)/3.14;
    double r = pow(a,1.0/3);
    printf("%.2lf",4*3.14*pow(r,2));
    return 0;
}